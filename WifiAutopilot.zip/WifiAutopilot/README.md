# Wi-Fi Autopilot

Personal Android app for a Vivo X200 FE (Android 16, OriginOS 6/7): switches Wi-Fi and mobile data for you, keeps working after reboots, uses **no accessibility service** (so banking apps such as bKash don't block it), and needs **no extra app running** — Shizuku is used once during setup and can then be uninstalled.

**Author:** Md Ershadul Haque Khan · personal use only (not for Google Play). `compileSdk 35`, `targetSdk 28` (on purpose, see below), `minSdk 26`. Version 5.0.

## What it does

| When | Automatic action |
|---|---|
| Wi-Fi disconnected for 5 s (leaving) | Wi-Fi **OFF**, mobile data **ON** |
| Wi-Fi off and a saved SSID shows up in background scans (arriving) | Wi-Fi **ON** |
| `NET_CAPABILITY_VALIDATED` arrives over `TRANSPORT_WIFI` | Mobile data **OFF** |
| Phone shutting down or restarting | Mobile data back **ON**, so it works straight after the restart |

It never fights you: if you switch Wi-Fi off yourself near Home, it stays off until you have left. It needs a minimum signal (default −75 dBm), waits 2 min after switching Wi-Fi off (longer if it keeps flip-flopping at the edge of range), and gives up after 60 s if Wi-Fi won't connect.

## How each switch works (no accessibility service, no Shizuku at runtime)

Banking and mobile-money apps (bKash and others) refuse to run while a sideloaded app has an accessibility service switched on, so this app has none. Everything it does at runtime uses `WRITE_SECURE_SETTINGS`, a permission granted **once** during setup and kept by Android across reboots.

| Switch | How | After a reboot |
|---|---|---|
| Wi-Fi ON/OFF | Android's own `WifiManager.setWifiEnabled()`. Android 10–16 still allow it for apps that target Android 9 (`targetSdk 28`). Silent, works while locked, needs no permission beyond `CHANGE_WIFI_STATE`. | Works at once, no Shizuku |
| Mobile data ON/OFF | `Settings.Global mobile_data<subId>` written with `WRITE_SECURE_SETTINGS` — **where this phone honours it**. The one-time setup tests this and remembers the result. | Works at once, no Shizuku |

**The honest limit on mobile data.** Android 16 offers no guaranteed way for a normal app to flip the mobile-data master switch: `TelephonyManager.setDataEnabled` needs `MODIFY_PHONE_STATE` (system apps only), and the only other routes are an accessibility service (blocked by bKash) or a shell-level helper. The `Settings.Global` method works on many phones but is ignored by some heavily-customised ROMs. So the app **tests it during the one-time setup, while Shizuku is still installed**, and tells you the result before you uninstall Shizuku:

- **Test passes** → mobile data switches fully off/on by itself, forever, with no Shizuku. Everything above is automatic.
- **Test fails** → the app can't force the data toggle off by itself. It leaves the switch on but sets `mobile_data_always_on = 0`, so **Android pauses mobile data whenever Wi-Fi has internet** — no data and practically no battery is used on Wi-Fi. If you want the toggle itself visibly off, keep Shizuku installed; otherwise you lose nothing in practice.

Safety nets:
- Before the phone switches off or restarts, a data switch the app turned off goes back ON (`ACTION_SHUTDOWN`), so you are never left without data after a restart.
- If you leave Wi-Fi with the data switch off and the app can't switch it on, a notification opens the Internet panel.
- Turning automation off hands the data switch back ON.
- Any accessibility entry left by version 3 is removed automatically.

Arrivals have one more safety net: the setup turns on Android's own **"Turn on Wi-Fi automatically"** (`wifi_wakeup_enabled = 1`), fed by this app's scans.

## Battery

Event-driven, no polling loop: `ConnectivityManager.NetworkCallback` while on Wi-Fi; while Wi-Fi is off it checks scan results only on scans Android already did, significant-motion, cell-tower changes (`TelephonyCallback.CellLocationListener`), screen-on/unlock, and a gentle timer (default 3 min, batched by Doze). No accessibility service, no GPS, no background ADB, nothing extra running.

## One-time setup (details in the setup guide)

The setup grants a permanent permission once. Do it **either** way:

- **With Shizuku (no computer):** install the free Shizuku app, open it and tap Start (Wireless debugging), allow Wi-Fi Autopilot in it, then tap **Run one-time setup** in the app. When it finishes you can **uninstall Shizuku**.
- **From a computer (no extra app):** with the phone on USB debugging, run once:
  `adb shell pm grant com.ershad.wifiautopilot android.permission.WRITE_SECURE_SETTINGS`
  then open the app and tap **Run one-time setup**.

The one-time setup grants `WRITE_SECURE_SETTINGS`, location (all the time), notifications and Wi-Fi control; removes battery limits; turns on Location, Wi-Fi scanning, Android's auto Wi-Fi and "mobile data pauses on Wi-Fi"; and **tests whether this phone can switch mobile data by itself**, showing the result.

Then:
1. Vivo: Autostart for Wi-Fi Autopilot, Associated startup, high background power, ignore battery optimisation; lock the app in Recents. If OriginOS asks whether the app may turn on WLAN, choose **Always allow**.
2. Add your Wi-Fi names and turn **Automation** on.

Developer options and USB debugging can be turned back off afterwards — nothing at runtime needs them. Updating over an older version keeps every permission (same signing key).

## Build (no Android Studio)

Upload `WifiAutopilot.zip` as it is (or the extracted files) to a GitHub repository with `.github/workflows/build.yml`. The workflow finds the project in the zip or in a sub-folder (if several zips are there, the newest app version is built), runs `./gradlew assembleDebug` and publishes `app-debug.apk`:
- **Releases** → `WifiAutopilot.apk` / `app-debug.apk`; in a public repository `https://github.com/<you>/<repo>/releases/latest/download/WifiAutopilot.apk` always points to the newest build
- or **Actions** → latest run → **Artifacts**

Every build is signed with the same key (`keystore/autopilot.keystore`) so updates install over the old version and keep all permissions. In a public repository that key is public too, so only install the APK from your own link.

## Files

```
app/src/main/java/com/ershad/wifiautopilot/
  MainActivity.kt                         Compose host
  App.kt                                  start-up wiring
  service/AutomationForegroundService.kt  event-driven foreground service (direct-boot aware)
  service/AutomationEngine.kt             the two-way rules, triggers, retries, shutdown safety net
  service/BootReceiver.kt                 BOOT_COMPLETED, LOCKED_BOOT_COMPLETED, QUICKBOOT_POWERON, app updated
  service/AlarmReceiver.kt                low-power periodic check
  control/DualEngineController.kt         engine order for every switch
  control/ShizukuHelper.kt                Shizuku engine — one-time setup only
  control/SystemSettings.kt               WRITE_SECURE_SETTINGS: system flags, data-switch test, old a11y cleanup
  control/RadioState.kt                   reading radios and Wi-Fi scans
  core/                                   settings, log, notifications, status, setup shortcuts
  ui/                                     Jetpack Compose screens
```
