package com.ershad.wifiautopilot.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import com.ershad.wifiautopilot.MainActivity
import com.ershad.wifiautopilot.R
import com.ershad.wifiautopilot.control.ShizukuHelper
import com.ershad.wifiautopilot.service.AutomationForegroundService

object Notifications {
    private const val CH_STATUS = "status"
    private const val CH_ALERTS = "alerts"
    const val ID_STATUS = 1
    private const val ID_ALERT = 2
    private const val ID_DATA_OFF = 3
    private const val ID_SHIZUKU = 4
    private const val ALERT_GAP_MS = 30 * 60_000L
    private const val SHIZUKU_ALERT_GAP_MS = 6 * 60 * 60_000L

    @Volatile private var lastAlertAt = 0L
    @Volatile private var lastDataAlertAt = 0L
    @Volatile private var lastShizukuAlertAt = 0L
    @Volatile var lastStatusText: String = "Watching your Wi-Fi…"
        private set

    fun createChannels(ctx: Context) {
        val nm = ctx.systemService<NotificationManager>()
        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "Automation status", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Quiet, always-on notification that keeps the automation running"
                setShowBadge(false)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERTS, "Problems that need you", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "For example when mobile data is switched off and can't be turned on automatically"
            }
        )
    }

    private fun pending(ctx: Context, code: Int, intent: Intent): PendingIntent = PendingIntent.getActivity(
        ctx, code, intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun statusNotification(ctx: Context, text: String = lastStatusText): Notification {
        lastStatusText = text
        val open = pending(ctx, 10, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP))
        val stop = PendingIntent.getService(
            ctx, 11,
            Intent(ctx, AutomationForegroundService::class.java).setAction(AutomationForegroundService.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val icon = Icon.createWithResource(ctx, R.drawable.ic_stat_autopilot)
        val builder = Notification.Builder(ctx, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_autopilot)
            .setContentTitle("Wi-Fi Autopilot is on")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(icon, "Turn off", stop).build())
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return builder.build()
    }

    fun updateStatus(ctx: Context, text: String) {
        if (text == lastStatusText) return
        ctx.systemService<NotificationManager>().notify(ID_STATUS, statusNotification(ctx, text))
    }

    fun cancelStatus(ctx: Context) {
        ctx.systemService<NotificationManager>().cancel(ID_STATUS)
    }

    /**
     * You left Wi-Fi but the mobile-data switch is OFF and nothing could turn it on silently
     * (Shizuku not running, ROM ignores Settings.Global). One tap opens the Internet panel.
     * Rare: the automation switches data back ON before every shutdown or restart.
     */
    fun alertDataOff(ctx: Context) {
        val now = SystemClock.elapsedRealtime()
        if (lastDataAlertAt != 0L && now - lastDataAlertAt < ALERT_GAP_MS) return
        lastDataAlertAt = now
        val target = if (Build.VERSION.SDK_INT >= 29) {
            Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        } else {
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        }
        val text = "You're off Wi-Fi but the mobile-data switch is off and the app couldn't switch it on by itself. " +
            "Tap here to switch it on yourself."
        val n = Notification.Builder(ctx, CH_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_autopilot)
            .setContentTitle("Mobile data is switched off")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(pending(ctx, 13, target))
            .build()
        ctx.systemService<NotificationManager>().notify(ID_DATA_OFF, n)
    }

    fun clearDataOffAlert(ctx: Context) {
        lastDataAlertAt = 0L
        ctx.systemService<NotificationManager>().cancel(ID_DATA_OFF)
    }

    /**
     * Shizuku isn't running (for example after a restart away from your trusted Wi-Fi), so the
     * mobile-data switch can't be flipped. One tap opens Shizuku; tap Start there. Shown at most
     * every 6 hours and removed as soon as Shizuku runs again.
     */
    fun alertStartShizuku(ctx: Context, dataIsOff: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (lastShizukuAlertAt != 0L && now - lastShizukuAlertAt < SHIZUKU_ALERT_GAP_MS) return
        lastShizukuAlertAt = now
        val target = ctx.packageManager.getLaunchIntentForPackage(ShizukuHelper.SHIZUKU_PACKAGE)
            ?: Intent(ctx, MainActivity::class.java)
        val text = if (dataIsOff) {
            "Shizuku stopped while mobile data was switched off, so data can't come back on by itself " +
                "when you leave. Tap, then tap Start in Shizuku."
        } else {
            "You're on Wi-Fi, so Android has paused mobile data, but its switch can only be turned off " +
                "while Shizuku runs. Tap, then tap Start in Shizuku."
        }
        val n = Notification.Builder(ctx, CH_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_autopilot)
            .setContentTitle("Start Shizuku to switch mobile data")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pending(ctx, 14, target))
            .build()
        ctx.systemService<NotificationManager>().notify(ID_SHIZUKU, n)
    }

    fun clearShizukuAlert(ctx: Context) {
        lastShizukuAlertAt = 0L
        ctx.systemService<NotificationManager>().cancel(ID_SHIZUKU)
    }

    /** Something couldn't be switched. Shown at most once every 30 minutes. */
    fun alertCantSwitch(ctx: Context, what: String) {
        val now = SystemClock.elapsedRealtime()
        if (lastAlertAt != 0L && now - lastAlertAt < ALERT_GAP_MS) return
        lastAlertAt = now
        val text = "$what Tap to open Wi-Fi Autopilot and check Setup and the activity log."
        val n = Notification.Builder(ctx, CH_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_autopilot)
            .setContentTitle("Wi-Fi Autopilot needs a look")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(pending(ctx, 12, Intent(ctx, MainActivity::class.java)))
            .build()
        ctx.systemService<NotificationManager>().notify(ID_ALERT, n)
    }

    fun clearAlert(ctx: Context) {
        lastAlertAt = 0L
        ctx.systemService<NotificationManager>().cancel(ID_ALERT)
    }
}
