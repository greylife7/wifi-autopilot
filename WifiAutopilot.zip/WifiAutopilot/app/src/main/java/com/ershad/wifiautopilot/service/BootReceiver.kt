package com.ershad.wifiautopilot.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.ershad.wifiautopilot.control.SystemSettings
import com.ershad.wifiautopilot.core.ActivityLog
import com.ershad.wifiautopilot.core.Prefs

/**
 * Starts the automation by itself after a reboot – already before you unlock the phone
 * (LOCKED_BOOT_COMPLETED), again after unlock (BOOT_COMPLETED), on Vivo/HTC fast-boot
 * (QUICKBOOT_POWERON) and after installing a new version of the app. No Shizuku involved.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Version 4 has no accessibility service; drop any entry left by version 3 (banking apps check it).
        if (SystemSettings.removeOldAccessibilityEntry(context)) {
            ActivityLog.add("Removed the old accessibility entry from version 3")
        }
        if (!Prefs.current.automationOn) return
        if (AutomationForegroundService.isRunning) return
        val event = when (intent.action) {
            Intent.ACTION_LOCKED_BOOT_COMPLETED -> "phone restarted (before unlock)"
            Intent.ACTION_BOOT_COMPLETED -> "phone restarted"
            Intent.ACTION_MY_PACKAGE_REPLACED -> "app updated"
            else -> "fast boot"
        }
        try {
            AutomationForegroundService.start(context)
            ActivityLog.add("Started automatically: $event")
        } catch (e: Exception) {
            ActivityLog.add("Couldn't start after $event (${e.javaClass.simpleName}). Open the app once.")
        }
    }
}
