package com.ershad.wifiautopilot.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.ershad.wifiautopilot.core.Prefs

/** The gentle periodic "are my networks nearby?" check while Wi-Fi is off. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val engine = AutomationForegroundService.engine
        if (engine != null) {
            engine.onAlarm()
        } else if (Prefs.current.automationOn) {
            try {
                AutomationForegroundService.start(context)
            } catch (e: Exception) {
                // Android may refuse a background start here; the service restarts on its own.
            }
        }
    }
}
