package com.ershad.wifiautopilot.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF0B6BCB),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD5E5FF),
    onPrimaryContainer = Color(0xFF001C3A),
    secondary = Color(0xFF00796B),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFC8F2EA),
    onSecondaryContainer = Color(0xFF00201C),
    tertiary = Color(0xFF6A5AA8),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFF6F8FC),
    onBackground = Color(0xFF181C21),
    surface = Color(0xFFF6F8FC),
    onSurface = Color(0xFF181C21),
    surfaceVariant = Color(0xFFE1E6EF),
    onSurfaceVariant = Color(0xFF434851),
    outline = Color(0xFF737882),
    outlineVariant = Color(0xFFC3C8D1),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFFFFFF),
    surfaceContainer = Color(0xFFEEF2F8),
    surfaceContainerHigh = Color(0xFFE8ECF3),
    surfaceContainerHighest = Color(0xFFE2E7EE),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFA6C8FF),
    onPrimary = Color(0xFF00305F),
    primaryContainer = Color(0xFF0B4A8A),
    onPrimaryContainer = Color(0xFFD5E5FF),
    secondary = Color(0xFF7DD8C9),
    onSecondary = Color(0xFF003731),
    secondaryContainer = Color(0xFF005047),
    onSecondaryContainer = Color(0xFFC8F2EA),
    tertiary = Color(0xFFCBBEFF),
    onTertiary = Color(0xFF33256F),
    background = Color(0xFF0F1418),
    onBackground = Color(0xFFE0E3E8),
    surface = Color(0xFF0F1418),
    onSurface = Color(0xFFE0E3E8),
    surfaceVariant = Color(0xFF2B3138),
    onSurfaceVariant = Color(0xFFC2C7CF),
    outline = Color(0xFF8C9199),
    outlineVariant = Color(0xFF42474E),
    surfaceContainerLowest = Color(0xFF0A0F13),
    surfaceContainerLow = Color(0xFF171D22),
    surfaceContainer = Color(0xFF1B2126),
    surfaceContainerHigh = Color(0xFF252B31),
    surfaceContainerHighest = Color(0xFF30363C),
)

@Composable
fun AutopilotTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}

/** Semantic colors for the status pills. */
enum class Tone { Good, Warn, Bad, Neutral }

@Composable
fun toneColor(tone: Tone): Color {
    val dark = isSystemInDarkTheme()
    return when (tone) {
        Tone.Good -> if (dark) Color(0xFF7FD992) else Color(0xFF1B7A35)
        Tone.Warn -> if (dark) Color(0xFFFFC46B) else Color(0xFF975A00)
        Tone.Bad -> if (dark) Color(0xFFFF8F87) else Color(0xFFB3261E)
        Tone.Neutral -> MaterialTheme.colorScheme.onSurfaceVariant
    }
}
