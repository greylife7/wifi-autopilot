package com.ershad.wifiautopilot.core

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray

/** Everything the user can change in the app. */
data class AutopilotSettings(
    val automationOn: Boolean = false,
    /** Exact Wi-Fi names (SSIDs) of Home, Office, etc. */
    val savedSsids: List<String> = emptyList(),
    /** How long Wi-Fi must stay disconnected before switching to mobile data. */
    val graceSeconds: Int = 5,
    /** How often to look for saved networks while Wi-Fi is off (moving, cell changes and screen-on also trigger a look). */
    val scanIntervalMin: Int = 3,
    /** A saved network must be at least this strong before Wi-Fi is switched back on. */
    val minRssi: Int = -75,
    /**
     * Switch mobile data OFF once Wi-Fi works (with Shizuku, or Settings.Global where the phone
     * honours it), and back ON when you leave. Without either, Android pauses mobile data on Wi-Fi.
     */
    val turnDataOffOnWifi: Boolean = true,
    /** Wait until Android confirms the Wi-Fi has internet (NET_CAPABILITY_VALIDATED) before switching data off. */
    val dataOffNeedsInternet: Boolean = true,
    /** Result of testing the Settings.Global mobile-data switch on this phone: 1 works, -1 doesn't, 0 not tested. */
    val globalDataSwitch: Int = 0,
    /** Last result of Android's own Wi-Fi switch (WifiManager): 1 works, -1 blocked, 0 not used yet. */
    val wifiSwitch: Int = 0,
)

object Prefs {
    private const val K_AUTO = "automation_on"
    private const val K_SSIDS = "saved_ssids"
    private const val K_GRACE = "grace_seconds"
    private const val K_INTERVAL = "scan_interval_min"
    private const val K_RSSI = "min_rssi"
    private const val K_DATA_OFF = "turn_data_off_on_wifi"
    private const val K_NEED_INTERNET = "data_off_needs_internet"
    private const val K_GLOBAL_DATA = "global_data_switch"
    private const val K_WIFI_SWITCH = "wifi_switch"
    // Settings of version 3's accessibility engine; removed on first start of version 4.
    private val OLD_KEYS = listOf("screen_engine_data_off", "keep_accessibility_on", "extra_wifi_labels", "extra_data_labels")
    private const val K_PREV_ALWAYS_ON = "prev_mobile_data_always_on"
    private const val K_DATA_OFF_BY_APP = "data_off_by_app"

    private lateinit var sp: SharedPreferences
    private val _state = MutableStateFlow(AutopilotSettings())

    val state: StateFlow<AutopilotSettings> = _state.asStateFlow()
    val current: AutopilotSettings get() = _state.value

    fun init(context: Context) {
        // Device-protected storage: readable right after a reboot, before the phone is unlocked,
        // so the automation can start immediately (LOCKED_BOOT_COMPLETED).
        val storage = context.createDeviceProtectedStorageContext()
        sp = storage.getSharedPreferences("autopilot_settings", Context.MODE_PRIVATE)
        if (OLD_KEYS.any { sp.contains(it) }) {
            sp.edit().apply { OLD_KEYS.forEach { remove(it) } }.apply()
        }
        _state.value = load()
    }

    @Synchronized
    fun update(change: (AutopilotSettings) -> AutopilotSettings) {
        val next = change(_state.value)
        _state.value = next
        save(next)
    }

    /** Adds names that aren't saved yet (case-insensitive). Returns the names actually added. */
    fun addSsids(names: List<String>): List<String> {
        val added = ArrayList<String>()
        update { s ->
            val list = s.savedSsids.toMutableList()
            for (raw in names) {
                val name = raw.trim()
                if (name.isNotEmpty() && list.none { it.equals(name, ignoreCase = true) }) {
                    list += name
                    added += name
                }
            }
            s.copy(savedSsids = list)
        }
        return added
    }

    fun removeSsid(name: String) {
        update { s -> s.copy(savedSsids = s.savedSsids.filterNot { it == name }) }
    }

    /** The user's own "mobile data always active" value from before the app changed it (-1 = not changed). */
    var previousAlwaysOn: Int
        get() = sp.getInt(K_PREV_ALWAYS_ON, -1)
        set(value) {
            sp.edit().putInt(K_PREV_ALWAYS_ON, value).apply()
        }

    /**
     * True while mobile data is OFF because this app switched it off (not you). Kept across reboots,
     * so after a restart without Shizuku the app knows it may switch data back on – and it never
     * overrides a switch you flipped yourself.
     */
    var dataOffByApp: Boolean
        get() = sp.getBoolean(K_DATA_OFF_BY_APP, false)
        set(value) {
            if (sp.getBoolean(K_DATA_OFF_BY_APP, false) != value) {
                // commit(), not apply(): this is also written while the phone is shutting down.
                sp.edit().putBoolean(K_DATA_OFF_BY_APP, value).commit()
            }
        }

    private fun load(): AutopilotSettings {
        val ssids = try {
            val arr = JSONArray(sp.getString(K_SSIDS, "[]") ?: "[]")
            List(arr.length()) { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
        return AutopilotSettings(
            automationOn = sp.getBoolean(K_AUTO, false),
            savedSsids = ssids,
            graceSeconds = sp.getInt(K_GRACE, 5).coerceIn(3, 30),
            scanIntervalMin = sp.getInt(K_INTERVAL, 3).coerceIn(1, 15),
            minRssi = sp.getInt(K_RSSI, -75).coerceIn(-90, -55),
            turnDataOffOnWifi = sp.getBoolean(K_DATA_OFF, true),
            dataOffNeedsInternet = sp.getBoolean(K_NEED_INTERNET, true),
            globalDataSwitch = sp.getInt(K_GLOBAL_DATA, 0).coerceIn(-1, 1),
            wifiSwitch = sp.getInt(K_WIFI_SWITCH, 0).coerceIn(-1, 1),
        )
    }

    private fun save(s: AutopilotSettings) {
        sp.edit()
            .putBoolean(K_AUTO, s.automationOn)
            .putString(K_SSIDS, JSONArray(s.savedSsids).toString())
            .putInt(K_GRACE, s.graceSeconds)
            .putInt(K_INTERVAL, s.scanIntervalMin)
            .putInt(K_RSSI, s.minRssi)
            .putBoolean(K_DATA_OFF, s.turnDataOffOnWifi)
            .putBoolean(K_NEED_INTERNET, s.dataOffNeedsInternet)
            .putInt(K_GLOBAL_DATA, s.globalDataSwitch)
            .putInt(K_WIFI_SWITCH, s.wifiSwitch)
            .apply()
    }
}
