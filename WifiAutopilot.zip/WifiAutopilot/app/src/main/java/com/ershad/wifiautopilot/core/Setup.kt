package com.ershad.wifiautopilot.core

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.ershad.wifiautopilot.control.ShizukuHelper
import com.ershad.wifiautopilot.control.SystemSettings

/** One-time permanent setup through Shizuku, plus shortcuts into system and Vivo settings screens. */
object Setup {

    data class Step(val label: String, val ok: Boolean)

    /**
     * ONE-TIME, PERMANENT: uses Shizuku's shell rights once to grant this app everything Android keeps
     * across reboots (above all WRITE_SECURE_SETTINGS), then tests whether this phone can switch mobile
     * data with that permission alone. After this runs, Shizuku can be uninstalled. Blocking: call off
     * the main thread.
     */
    fun runPermanentSetup(ctx: Context): List<Step> {
        val pkg = ctx.packageName
        val steps = ArrayList<Step>()
        fun sh(label: String, command: String) {
            val r = ShizukuHelper.run(command)
            val failed = !r.ok || r.err.contains("Exception") || r.out.contains("Exception")
            steps += Step(label, !failed)
        }
        // Permissions (all survive reboots)
        sh("Permanent permission WRITE_SECURE_SETTINGS", "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS")
        sh("Location permission", "pm grant $pkg android.permission.ACCESS_FINE_LOCATION")
        sh("Approximate location", "pm grant $pkg android.permission.ACCESS_COARSE_LOCATION")
        sh("Location all the time", "pm grant $pkg android.permission.ACCESS_BACKGROUND_LOCATION")
        sh("Notifications", "pm grant $pkg android.permission.POST_NOTIFICATIONS")
        sh("Wi-Fi control allowed", "cmd appops set $pkg CHANGE_WIFI_STATE allow")
        // Battery (stored by Android, survives reboots)
        sh("Battery: ignore optimisation", "dumpsys deviceidle whitelist +$pkg")
        sh("Battery: allow background running", "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow")
        sh("Battery: allow background services", "cmd appops set $pkg RUN_IN_BACKGROUND allow")
        // System switches the automation relies on
        sh("Location ON", "cmd location set-location-enabled true")
        sh("Wi-Fi scanning ON (works while Wi-Fi is off)", "cmd wifi set-scan-always-available enabled")

        // The rest uses the permanent permission granted above (no Shizuku needed for these later).
        val secure = SystemSettings.hasPermission(ctx)
        if (secure) SystemSettings.ensureSystemFlags(ctx)
        steps += Step(
            "Android's “Turn on Wi-Fi automatically” ON",
            (secure && SystemSettings.isWifiWakeOn(ctx)) || ShizukuHelper.run("settings put global wifi_wakeup_enabled 1").ok,
        )
        steps += Step(
            "Cellular data pauses while on Wi-Fi",
            (secure && SystemSettings.cellularPausesOnWifi(ctx)) || ShizukuHelper.run("settings put global mobile_data_always_on 0").ok,
        )
        // Mobile data: test whether this phone switches it silently with the permanent permission
        // alone (Settings.Global). Done now, while Shizuku is still here, so the result is known
        // BEFORE Shizuku is uninstalled. The test puts the switch back the way it found it.
        if (secure) {
            val result = SystemSettings.testSettingsDataSwitch(ctx)
            steps += Step("Mobile-data switch — $result", Prefs.current.globalDataSwitch == 1)
        } else {
            steps += Step("Mobile-data switch test needs the permanent permission first", false)
        }
        steps += Step(
            "No accessibility service (banking apps stay happy)",
            !SystemSettings.hasOldAccessibilityEntry(ctx) || SystemSettings.removeOldAccessibilityEntry(ctx),
        )

        ActivityLog.add("One-time setup: ${steps.count { it.ok }} of ${steps.size} steps done")
        return steps
    }

    fun openShizuku(ctx: Context): Boolean {
        val launch = ctx.packageManager.getLaunchIntentForPackage(ShizukuHelper.SHIZUKU_PACKAGE) ?: return false
        return start(ctx, launch)
    }

    fun openUrl(ctx: Context, url: String): Boolean = start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    fun openAppSettings(ctx: Context): Boolean = start(
        ctx,
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)),
    )

    fun openNotificationSettings(ctx: Context): Boolean = start(
        ctx,
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName),
    ) || openAppSettings(ctx)

    fun openLocationSettings(ctx: Context): Boolean = start(ctx, Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))

    /** System dialog: "Let app always run in background?" */
    fun requestIgnoreBatteryOptimizations(ctx: Context): Boolean {
        val direct = Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse("package:" + ctx.packageName),
        )
        return start(ctx, direct) || start(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }

    // ---------------------------------------------------------------- Vivo / OriginOS screens
    // Vivo's switches can't be flipped by an app; these open the right screen so you flip them once.
    // Screen names differ between Funtouch OS and OriginOS versions, so several are tried in order,
    // falling back to this app's "App info" page.

    fun openVivoAutostart(ctx: Context): Boolean = tryComponents(
        ctx,
        listOf(
            ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
            ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"),
            ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.PurviewTabActivity"),
            ComponentName("com.iqoo.secure", "com.iqoo.secure.safeguard.PurviewTabActivity"),
        ),
    )

    fun openVivoAssociatedStartup(ctx: Context): Boolean {
        val perApp = Intent()
            .setComponent(ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.SoftPermissionDetailActivity"))
            .putExtra("packagename", ctx.packageName)
        if (start(ctx, perApp)) return true
        return openVivoAutostart(ctx)
    }

    fun openVivoBackgroundPower(ctx: Context): Boolean = tryComponents(
        ctx,
        listOf(
            ComponentName("com.vivo.abe", "com.vivo.applicationbehaviorengine.ui.ExcessivePowerManagerActivity"),
            ComponentName("com.iqoo.powersaving", "com.iqoo.powersaving.PowerSavingManagerActivity"),
            ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"),
        ),
    )

    private fun tryComponents(ctx: Context, components: List<ComponentName>): Boolean {
        for (c in components) {
            if (start(ctx, Intent().setComponent(c))) return true
        }
        return openAppSettings(ctx)
    }

    private fun start(ctx: Context, intent: Intent): Boolean = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Throwable) {
        false
    }
}
