package com.ershad.wifiautopilot.core

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.os.PowerManager
import android.provider.Settings
import com.ershad.wifiautopilot.control.DualEngineController
import com.ershad.wifiautopilot.control.RadioState
import com.ershad.wifiautopilot.control.ShizukuHelper
import com.ershad.wifiautopilot.control.SystemSettings
import com.ershad.wifiautopilot.service.AutomationForegroundService

/** A snapshot of everything the dashboard shows. */
data class SystemStatus(
    val wifiOn: Boolean = false,
    val wifiConnected: Boolean = false,
    val wifiInternet: Boolean = false,
    val ssid: String? = null,
    val mobileData: Boolean? = null,
    val cellularActive: Boolean = false,
    val airplane: Boolean = false,
    val locationOn: Boolean = false,
    val wifiScanningOn: Boolean = false,
    val wifiWakeOn: Boolean = false,
    val cellularPausesOnWifi: Boolean = false,
    val fineLocation: Boolean = false,
    val backgroundLocation: Boolean = false,
    val notifications: Boolean = false,
    val secureSettings: Boolean = false,
    /** Android lets this app switch Wi-Fi itself (it targets SDK 28). */
    val nativeWifiSwitch: Boolean = false,
    /** An accessibility entry from version 3 is still switched on (banking apps object to it). */
    val oldAccessibilityEntry: Boolean = false,
    /** Installed Shizuku version, or null when it isn't installed (needed only for the one-time setup). */
    val shizukuVersion: String? = null,
    /** Result of the one-time data-switch test: 1 = works standalone, -1 = needs Shizuku, 0 = not tested. */
    val dataSwitchTest: Int = 0,
    val batteryUnrestricted: Boolean = false,
    val exactAlarms: Boolean = false,
    val serviceRunning: Boolean = false,
) {
    /** Everything needed to keep working after a reboot with no Shizuku. */
    val rebootProof: Boolean
        get() = secureSettings && nativeWifiSwitch && fineLocation && backgroundLocation &&
            locationOn && wifiScanningOn && wifiWakeOn

    companion object {
        fun read(ctx: Context): SystemStatus {
            val wm: WifiManager = ctx.applicationContext.systemService()
            val pm: PowerManager = ctx.systemService()
            val lm: LocationManager = ctx.systemService()
            val am: AlarmManager = ctx.systemService()
            val nm: NotificationManager = ctx.systemService()
            fun granted(permission: String) =
                ctx.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

            val (connected, internet) = RadioState.wifiLink(ctx)
            @Suppress("DEPRECATION")
            val scanAlways = try { wm.isScanAlwaysAvailable } catch (e: Throwable) { false }
            val airplane = try {
                Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
            } catch (e: Throwable) {
                false
            }

            return SystemStatus(
                wifiOn = wm.isWifiEnabled,
                wifiConnected = connected,
                wifiInternet = internet,
                ssid = if (connected) RadioState.connectedSsid(ctx) else null,
                mobileData = RadioState.isMobileDataOn(ctx),
                cellularActive = RadioState.isCellularDataActive(ctx),
                airplane = airplane,
                locationOn = try { lm.isLocationEnabled } catch (e: Throwable) { false },
                wifiScanningOn = scanAlways,
                wifiWakeOn = SystemSettings.isWifiWakeOn(ctx),
                cellularPausesOnWifi = SystemSettings.cellularPausesOnWifi(ctx),
                fineLocation = granted(Manifest.permission.ACCESS_FINE_LOCATION),
                backgroundLocation = granted(Manifest.permission.ACCESS_BACKGROUND_LOCATION),
                notifications = try { nm.areNotificationsEnabled() } catch (e: Throwable) { false },
                secureSettings = SystemSettings.hasPermission(ctx),
                nativeWifiSwitch = DualEngineController.canSwitchWifiNatively(ctx),
                oldAccessibilityEntry = SystemSettings.hasOldAccessibilityEntry(ctx),
                shizukuVersion = ShizukuHelper.installedVersion(),
                dataSwitchTest = Prefs.current.globalDataSwitch,
                batteryUnrestricted = pm.isIgnoringBatteryOptimizations(ctx.packageName),
                exactAlarms = try { am.canScheduleExactAlarms() } catch (e: Throwable) { false },
                serviceRunning = AutomationForegroundService.isRunning,
            )
        }
    }
}
