package com.ershad.wifiautopilot.ui

import android.Manifest
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.ershad.wifiautopilot.BuildConfig
import com.ershad.wifiautopilot.control.DualEngineController
import com.ershad.wifiautopilot.control.RadioState
import com.ershad.wifiautopilot.control.ShizukuHelper
import com.ershad.wifiautopilot.control.SystemSettings
import com.ershad.wifiautopilot.core.ActivityLog
import com.ershad.wifiautopilot.core.AutopilotSettings
import com.ershad.wifiautopilot.core.Prefs
import com.ershad.wifiautopilot.core.Setup
import com.ershad.wifiautopilot.core.SystemStatus
import com.ershad.wifiautopilot.service.AutomationForegroundService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** A titled list shown in a dialog (setup results, learned tile names). */
private data class InfoList(val title: String, val lines: List<String>, val footer: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val settings by Prefs.state.collectAsStateWithLifecycle()
    val log by ActivityLog.entries.collectAsStateWithLifecycle()
    val shizuku by ShizukuHelper.state.collectAsStateWithLifecycle()
    var status by remember { mutableStateOf(SystemStatus()) }
    var busy by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<InfoList?>(null) }

    fun refresh() {
        scope.launch { status = withContext(Dispatchers.IO) { SystemStatus.read(context) } }
    }

    fun message(text: String) {
        scope.launch { snackbar.showSnackbar(text) }
    }

    // Live dashboard: refresh every 2 seconds while the screen is visible
    val lifecycleOwner = LocalLifecycleOwner.current
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                ShizukuHelper.refresh()
                status = withContext(Dispatchers.IO) { SystemStatus.read(context) }
                delay(2_000)
            }
        }
    }

    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refresh() }

    fun settingsChanged() {
        AutomationForegroundService.engine?.onSettingsChanged()
    }

    fun setAutomation(on: Boolean) {
        Prefs.update { it.copy(automationOn = on) }
        if (on) {
            try {
                AutomationForegroundService.start(context)
            } catch (e: Exception) {
                message("Android blocked the background service: ${e.javaClass.simpleName}")
            }
            when {
                !status.rebootProof -> message("Automation is on. Finish Setup below so it keeps working after reboots.")
                settings.savedSsids.isEmpty() -> message("Now add your Wi-Fi names under “My saved Wi-Fi names”.")
            }
        } else {
            AutomationForegroundService.stop(context)
            scope.launch {
                withContext(Dispatchers.IO) {
                    SystemSettings.restoreAlwaysOn(context)
                    DualEngineController.restoreMobileData(context)
                }
                refresh()
            }
            ActivityLog.add("Automation turned off")
        }
        refresh()
    }

    fun addNetworks(names: List<String>) {
        val added = Prefs.addSsids(names)
        if (added.isNotEmpty()) settingsChanged()
        message(if (added.isEmpty()) "Already in your list" else "Added: " + added.joinToString(", "))
    }

    /** Runs blocking work off the main thread, then logs and shows its one-line result. */
    fun runInBackground(work: () -> String) {
        busy = true
        scope.launch {
            val text = withContext(Dispatchers.IO) { work() }
            busy = false
            ActivityLog.add(text)
            message(text)
            refresh()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Wi-Fi Autopilot", fontWeight = FontWeight.SemiBold) })
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                AutomationCard(
                    on = settings.automationOn,
                    rebootProof = status.rebootProof,
                    hasNetworks = settings.savedSsids.isNotEmpty(),
                    onToggle = { setAutomation(it) },
                )
            }
            item { StatusCard(status, shizuku, settings) }
            item {
                EnginesCard(
                    status = status,
                    shizuku = shizuku,
                    globalDataSwitch = settings.globalDataSwitch,
                    busy = busy,
                    onShizuku = {
                        when (shizuku) {
                            ShizukuHelper.State.NOT_INSTALLED ->
                                Setup.openUrl(context, ShizukuHelper.SHIZUKU_RELEASES_URL)
                            ShizukuHelper.State.NOT_RUNNING ->
                                if (!Setup.openShizuku(context)) message("Couldn't open Shizuku")
                            ShizukuHelper.State.NO_PERMISSION ->
                                if (!ShizukuHelper.requestPermission()) {
                                    message("In Shizuku, open “Authorized applications” and turn on Wi-Fi Autopilot")
                                    Setup.openShizuku(context)
                                }
                            ShizukuHelper.State.READY -> Unit
                        }
                    },
                    onPermanentSetup = {
                        busy = true
                        scope.launch {
                            val steps = withContext(Dispatchers.IO) { Setup.runPermanentSetup(context) }
                            busy = false
                            val dataWorks = Prefs.current.globalDataSwitch == 1
                            info = InfoList(
                                title = "One-time setup",
                                lines = steps.map { (if (it.ok) "✅ " else "⚠️ ") + it.label },
                                footer = when {
                                    !steps.first().ok ->
                                        "The key permission wasn't granted. Make sure Shizuku says “running”, then try again."
                                    dataWorks ->
                                        "Done — Android keeps all of this after every reboot. Mobile data switches fully " +
                                            "off by itself on this phone, so you can uninstall Shizuku now."
                                    else ->
                                        "Done — Android keeps all of this after every reboot. This phone won't switch the " +
                                            "mobile-data toggle fully off without Shizuku, but Android still pauses mobile data " +
                                            "on Wi-Fi (no data used). You can uninstall Shizuku now, or keep it if you want the " +
                                            "toggle itself off — your choice."
                                },
                            )
                            settingsChanged()
                            refresh()
                        }
                    },
                    onTestGlobal = { runInBackground { SystemSettings.testSettingsDataSwitch(context) } },
                )
            }
            item {
                LocationCard(
                    status = status,
                    onLocationPermission = {
                        if (!status.fineLocation) {
                            locationLauncher.launch(
                                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                            )
                        } else {
                            message("Permissions → Location → Allow all the time")
                            Setup.openAppSettings(context)
                        }
                    },
                    onLocationSettings = { Setup.openLocationSettings(context) },
                    onScanningNow = {
                        scope.launch {
                            withContext(Dispatchers.IO) { SystemSettings.ensureSystemFlags(context) }
                            if (!status.secureSettings) {
                                message("Location → Location services → Wi-Fi scanning: turn it ON")
                                Setup.openLocationSettings(context)
                            }
                            refresh()
                        }
                    },
                    onNotifications = { Setup.openNotificationSettings(context) },
                )
            }
            item {
                VivoCard(
                    batteryUnrestricted = status.batteryUnrestricted,
                    onBattery = { Setup.requestIgnoreBatteryOptimizations(context) },
                    onAutostart = { Setup.openVivoAutostart(context) },
                    onAssociated = { Setup.openVivoAssociatedStartup(context) },
                    onBackgroundPower = { Setup.openVivoBackgroundPower(context) },
                )
            }
            item {
                NetworksCard(
                    ssids = settings.savedSsids,
                    currentSsid = status.ssid,
                    shizukuReady = shizuku == ShizukuHelper.State.READY,
                    onAdd = { addNetworks(listOf(it)) },
                    onRemove = {
                        Prefs.removeSsid(it)
                        settingsChanged()
                    },
                    onImport = {
                        busy = true
                        scope.launch {
                            val result = withContext(Dispatchers.IO) { RadioState.importSavedNetworks() }
                            busy = false
                            result.fold(
                                onSuccess = { names ->
                                    if (names.isEmpty()) message("No saved Wi-Fi networks found on the phone") else addNetworks(names)
                                },
                                onFailure = { e -> message(e.message ?: "Import failed") },
                            )
                        }
                    },
                )
            }
            item {
                BehaviourCard(settings) { updated ->
                    Prefs.update { updated }
                    settingsChanged()
                }
            }
            item {
                TuningCard(settings) { updated ->
                    Prefs.update { updated }
                    settingsChanged()
                }
            }
            item {
                TestCard(
                    busy = busy,
                    onLeave = {
                        runInBackground {
                            val w = DualEngineController.setWifi(context, false)
                            val d = DualEngineController.setMobileData(context, true)
                            "Test leaving: Wi-Fi OFF → ${describe(w)}, mobile data ON → ${describe(d)}"
                        }
                    },
                    onArrive = {
                        runInBackground {
                            val w = DualEngineController.setWifi(context, true)
                            "Test arriving: Wi-Fi ON → ${describe(w)}"
                        }
                    },
                    onScan = {
                        val saved = settings.savedSsids
                        runInBackground { RadioState.scanReport(context, saved) }
                    },
                )
            }
            item { LogCard(log, onClear = { ActivityLog.clear() }) }
            item {
                Text(
                    "Wi-Fi Autopilot ${BuildConfig.VERSION_NAME} · by Md Ershadul Haque Khan",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }

    val shown = info
    if (shown != null) {
        AlertDialog(
            onDismissRequest = { info = null },
            confirmButton = { TextButton(onClick = { info = null }) { Text("OK") } },
            title = { Text(shown.title) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    shown.lines.forEach { line -> Text(line, style = MaterialTheme.typography.bodyMedium) }
                    Spacer(Modifier.height(6.dp))
                    Text(shown.footer, style = MaterialTheme.typography.bodySmall)
                }
            },
        )
    }
}

private fun describe(r: DualEngineController.Result): String = when (r.outcome) {
    DualEngineController.Outcome.DONE -> "done (${r.via})"
    DualEngineController.Outcome.FAILED -> "failed (${r.via})"
}

// ------------------------------------------------------------------ cards

@Composable
private fun AutomationCard(on: Boolean, rebootProof: Boolean, hasNetworks: Boolean, onToggle: (Boolean) -> Unit) {
    val container = if (on) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val content = if (on) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = container, contentColor = content),
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Automation", style = MaterialTheme.typography.labelLarge)
                    Text(
                        if (on) "ON" else "OFF",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Switch(checked = on, onCheckedChange = onToggle)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (on) {
                    "Leave Wi-Fi → Wi-Fi OFF, mobile data ON.\nNear your saved Wi-Fi → Wi-Fi ON, mobile data OFF."
                } else {
                    "Turn on to let the app switch Wi-Fi and mobile data for you."
                },
                style = MaterialTheme.typography.bodyMedium,
            )
            if (on) {
                Spacer(Modifier.height(8.dp))
                Text(
                    if (rebootProof) "✅ Reboot-proof: keeps working after restarts without Shizuku."
                    else "⚠️ Not reboot-proof yet — finish the Setup cards below.",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            if (on && !hasNetworks) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "⚠️ Add your Wi-Fi names below so it knows where to turn Wi-Fi back on.",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

@Composable
private fun StatusCard(s: SystemStatus, shizuku: ShizukuHelper.State, settings: AutopilotSettings) {
    SectionCard("Live status") {
        StatusRow("Wi-Fi radio", if (s.wifiOn) "ON" else "OFF", if (s.wifiOn) Tone.Good else Tone.Neutral)
        val ssid = s.ssid
        val connectedText = when {
            s.wifiConnected && ssid != null -> ssid
            s.wifiConnected -> "Connected (name hidden)"
            else -> "Not connected"
        }
        StatusRow("Connected to", connectedText, if (s.wifiConnected) Tone.Good else Tone.Neutral)
        if (s.wifiConnected) {
            StatusRow(
                "Internet over Wi-Fi",
                if (s.wifiInternet) "Validated" else "Not confirmed",
                if (s.wifiInternet) Tone.Good else Tone.Warn,
            )
        }
        StatusRow(
            "Mobile data switch",
            when (s.mobileData) {
                true -> "ON"
                false -> "OFF"
                null -> "Unknown"
            },
            if (s.mobileData == true) Tone.Good else Tone.Neutral,
        )
        StatusRow(
            "Cellular data connection",
            if (s.cellularActive) "In use" else if (s.mobileData == true) "Paused" else "Off",
            if (s.cellularActive) Tone.Good else Tone.Neutral,
        )
        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        Text("Dual-engine controller", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
        StatusRow(
            "Wi-Fi switch (built into Android)",
            when {
                !s.nativeWifiSwitch -> "Not available"
                settings.wifiSwitch == 1 -> "Works"
                settings.wifiSwitch == -1 -> "Blocked — see log"
                else -> "Ready"
            },
            if (!s.nativeWifiSwitch || settings.wifiSwitch == -1) Tone.Bad else Tone.Good,
        )
        StatusRow(
            "Mobile data on Wi-Fi",
            when {
                settings.globalDataSwitch == 1 -> "Switches off by itself"
                s.cellularPausesOnWifi -> "Stays on, paused by Android"
                else -> "Run the one-time setup"
            },
            when {
                settings.globalDataSwitch == 1 -> Tone.Good
                s.cellularPausesOnWifi -> Tone.Neutral
                else -> Tone.Warn
            },
        )
        StatusRow(
            "Mobile-data switch test",
            when (s.dataSwitchTest) {
                1 -> "Works on this phone"
                -1 -> "Not supported — see Setup"
                else -> "Not tested yet"
            },
            when (s.dataSwitchTest) {
                1 -> Tone.Good
                -1 -> Tone.Warn
                else -> Tone.Neutral
            },
        )
        StatusRow(
            "Shizuku (one-time setup only)",
            when (shizuku) {
                ShizukuHelper.State.READY -> "Running"
                ShizukuHelper.State.NO_PERMISSION -> "Needs your OK"
                ShizukuHelper.State.NOT_RUNNING -> "Installed, not running"
                ShizukuHelper.State.NOT_INSTALLED -> "Not installed"
            },
            when (shizuku) {
                ShizukuHelper.State.READY -> Tone.Good
                ShizukuHelper.State.NO_PERMISSION -> Tone.Warn
                else -> Tone.Neutral
            },
        )
        StatusRow(
            "Accessibility service",
            if (s.oldAccessibilityEntry) "Old entry left" else "None (bank-safe)",
            if (s.oldAccessibilityEntry) Tone.Warn else Tone.Good,
        )
        StatusRow(
            "Permanent permission",
            if (s.secureSettings) "Granted" else "Not yet",
            if (s.secureSettings) Tone.Good else Tone.Bad,
        )
        StatusRow(
            "Works after reboot (no Shizuku)",
            if (s.rebootProof) "Yes" else "Not yet",
            if (s.rebootProof) Tone.Good else Tone.Warn,
        )
        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        StatusRow("Location", if (s.locationOn) "ON" else "OFF", if (s.locationOn) Tone.Good else Tone.Bad)
        StatusRow(
            "Wi-Fi scanning (while off)",
            if (s.wifiScanningOn) "ON" else "OFF",
            if (s.wifiScanningOn) Tone.Good else Tone.Bad,
        )
        StatusRow("Android auto Wi-Fi", if (s.wifiWakeOn) "ON" else "OFF", if (s.wifiWakeOn) Tone.Good else Tone.Warn)
        StatusRow(
            "Cellular pauses on Wi-Fi",
            if (s.cellularPausesOnWifi) "Yes" else "No",
            if (s.cellularPausesOnWifi) Tone.Good else Tone.Neutral,
        )
        StatusRow(
            "Background service",
            if (s.serviceRunning) "Running" else "Stopped",
            if (s.serviceRunning) Tone.Good else Tone.Neutral,
        )
        if (s.airplane) StatusRow("Airplane mode", "ON — paused", Tone.Warn)
    }
}

@Composable
private fun EnginesCard(
    status: SystemStatus,
    shizuku: ShizukuHelper.State,
    globalDataSwitch: Int,
    busy: Boolean,
    onShizuku: () -> Unit,
    onPermanentSetup: () -> Unit,
    onTestGlobal: () -> Unit,
) {
    val ready = shizuku == ShizukuHelper.State.READY
    SectionCard(
        "Setup · one time (then uninstall Shizuku)",
        "Install Shizuku once, run the setup, then you can uninstall it. The setup grants a permanent " +
            "permission the app keeps after Shizuku is gone and across reboots. Wi-Fi switching needs no " +
            "Shizuku at all, and there is no accessibility service. (No Shizuku? The guide shows how to grant " +
            "the same permission once from a computer instead.)",
    ) {
        SetupRow(
            title = "1. Install & start Shizuku (one time)",
            state = if (ready) StepState.Done else StepState.Todo,
            help = when (shizuku) {
                ShizukuHelper.State.NOT_INSTALLED -> "Install the free Shizuku app (GitHub), then open it and tap Start."
                ShizukuHelper.State.NOT_RUNNING -> "Open Shizuku and tap Start (it uses Wireless debugging)."
                ShizukuHelper.State.NO_PERMISSION -> "Shizuku is running. Allow Wi-Fi Autopilot to use it."
                ShizukuHelper.State.READY -> ""
            },
            actionLabel = when (shizuku) {
                ShizukuHelper.State.NOT_INSTALLED -> "Get Shizuku"
                ShizukuHelper.State.NOT_RUNNING -> "Open Shizuku"
                ShizukuHelper.State.NO_PERMISSION -> "Allow access"
                ShizukuHelper.State.READY -> null
            },
            onAction = onShizuku,
        )
        SetupRow(
            title = "2. Run the one-time setup",
            state = if (status.secureSettings && status.wifiWakeOn && status.backgroundLocation) StepState.Done else StepState.Todo,
            help = "Grants WRITE_SECURE_SETTINGS and location for good, removes battery limits, turns on Location, " +
                "Wi-Fi scanning, Android's auto Wi-Fi and \"pause mobile data on Wi-Fi\", then tests the mobile-data " +
                "switch on this phone." + (if (!ready) " Needs Shizuku running." else ""),
            actionLabel = if (busy) "Working…" else "Run one-time setup",
            onAction = onPermanentSetup,
            actionEnabled = ready && !busy,
        )
        SetupRow(
            title = "3. Mobile-data switch on this phone",
            state = when (globalDataSwitch) {
                1 -> StepState.Done
                -1 -> StepState.Info
                else -> StepState.Todo
            },
            help = when (globalDataSwitch) {
                1 -> ""
                -1 -> "Tested: this phone won't switch the mobile-data toggle fully off by itself (normal on " +
                    "Android 13–16 / OriginOS). Android still pauses mobile data on Wi-Fi, so no data is used. " +
                    "Keep Shizuku installed only if you want the toggle itself off; otherwise you're done."
                else -> "Run the one-time setup first — it tests this automatically. You can also re-test here."
            },
            actionLabel = if (globalDataSwitch == 1) null else "Test the data switch",
            onAction = onTestGlobal,
            actionEnabled = status.secureSettings && !busy,
        )
        SetupRow(
            title = "4. Uninstall Shizuku (optional)",
            state = if (status.secureSettings) StepState.Info else StepState.Todo,
            help = if (status.secureSettings) {
                "The permanent permission is granted, so the app no longer needs Shizuku" +
                    (if (globalDataSwitch == 1) " — safe to uninstall it now." else ". Keep it only if you want the data toggle fully off.")
            } else {
                "Finish steps 1–2 first."
            },
            actionLabel = null,
            onAction = {},
        )
    }
}

@Composable
private fun LocationCard(
    status: SystemStatus,
    onLocationPermission: () -> Unit,
    onLocationSettings: () -> Unit,
    onScanningNow: () -> Unit,
    onNotifications: () -> Unit,
) {
    SectionCard(
        "Location & Wi-Fi scanning",
        "Lets the phone see your saved Wi-Fi while the Wi-Fi button is OFF. Location on its own doesn't drain battery.",
    ) {
        SetupRow(
            title = "Location permission: Allow all the time",
            state = if (status.fineLocation && status.backgroundLocation) StepState.Done else StepState.Todo,
            help = "Android hides Wi-Fi names and scan results from apps without it.",
            actionLabel = if (!status.fineLocation) "Allow location" else "Allow all the time",
            onAction = onLocationPermission,
        )
        SetupRow(
            title = "Location switched on",
            state = if (status.locationOn) StepState.Done else StepState.Todo,
            help = "Android only scans for Wi-Fi in the background while Location is on.",
            actionLabel = "Open location settings",
            onAction = onLocationSettings,
        )
        SetupRow(
            title = "Wi-Fi scanning + Android auto Wi-Fi",
            state = if (status.wifiScanningOn && status.wifiWakeOn) StepState.Done else StepState.Todo,
            help = "Wi-Fi scanning works while Wi-Fi is off; Android's auto Wi-Fi turns Wi-Fi on near saved " +
                "networks even while the phone is locked.",
            actionLabel = "Turn them on",
            onAction = onScanningNow,
        )
        SetupRow(
            title = "Notifications",
            state = if (status.notifications) StepState.Done else StepState.Todo,
            help = "Shows the quiet status notification and warnings.",
            actionLabel = "Allow notifications",
            onAction = onNotifications,
        )
    }
}

@Composable
private fun VivoCard(
    batteryUnrestricted: Boolean,
    onBattery: () -> Unit,
    onAutostart: () -> Unit,
    onAssociated: () -> Unit,
    onBackgroundPower: () -> Unit,
) {
    SectionCard(
        "Vivo / OriginOS: start on boot & stay alive",
        "No app can change Vivo's own switches. Each button opens the right screen (or App info if your " +
            "OriginOS version names it differently) — turn the option on for Wi-Fi Autopilot.",
    ) {
        SetupRow(
            title = "Ignore battery optimisation",
            state = if (batteryUnrestricted) StepState.Done else StepState.Todo,
            help = "Android's own “don't optimise” — stops Doze from pausing the app.",
            actionLabel = "Ignore battery optimisation",
            onAction = onBattery,
        )
        SetupRow(
            title = "Autostart",
            state = StepState.Info,
            help = "Lets the app start itself after a reboot.",
            actionLabel = "Open Autostart",
            onAction = onAutostart,
        )
        SetupRow(
            title = "Associated startup",
            state = StepState.Info,
            help = "Lets Android's boot and alarm signals wake the app.",
            actionLabel = "Open Associated startup",
            onAction = onAssociated,
        )
        SetupRow(
            title = "Background power",
            state = StepState.Info,
            help = "Allow “high background power consumption” / “background activity”, and lock the app in " +
                "the Recents screen (pull its card down).",
            actionLabel = "Open background power",
            onAction = onBackgroundPower,
        )
    }
}

@Composable
private fun NetworksCard(
    ssids: List<String>,
    currentSsid: String?,
    shizukuReady: Boolean,
    onAdd: (String) -> Unit,
    onRemove: (String) -> Unit,
    onImport: () -> Unit,
) {
    var text by rememberSaveable { mutableStateOf("") }
    fun submit() {
        val name = text.trim()
        if (name.isNotEmpty()) {
            onAdd(name)
            text = ""
        }
    }
    SectionCard(
        "My saved Wi-Fi names (SSIDs)",
        "Exact names of Home, Office, etc. Wi-Fi turns back on when one of these is nearby.",
    ) {
        if (ssids.isEmpty()) {
            Text(
                "No networks yet — add Home, Office, …",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        ssids.forEach { name ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "📶  $name",
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { onRemove(name) }) {
                    Icon(Icons.Filled.Delete, contentDescription = "Remove $name")
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            singleLine = true,
            label = { Text("Wi-Fi name, exactly as shown") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { submit() }),
            trailingIcon = {
                IconButton(onClick = { submit() }, enabled = text.isNotBlank()) {
                    Icon(Icons.Filled.Add, contentDescription = "Add")
                }
            },
        )
        Spacer(Modifier.height(8.dp))
        if (currentSsid != null && ssids.none { it.equals(currentSsid, ignoreCase = true) }) {
            OutlinedButton(onClick = { onAdd(currentSsid) }, modifier = Modifier.fillMaxWidth()) {
                Text("Add the current Wi-Fi: $currentSsid", maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        OutlinedButton(onClick = onImport, enabled = shizukuReady, modifier = Modifier.fillMaxWidth()) {
            Text("Import saved networks (Shizuku)")
        }
    }
}

@Composable
private fun BehaviourCard(s: AutopilotSettings, onChange: (AutopilotSettings) -> Unit) {
    SectionCard(
        "Mobile data",
        "On Wi-Fi the mobile-data switch goes OFF, and back ON when you leave — where this phone lets the app " +
            "switch it (checked during setup). Where it doesn't, the switch stays on but Android pauses mobile " +
            "data on Wi-Fi, so no data is used.",
    ) {
        SwitchRow(
            title = "Switch mobile data OFF on Wi-Fi",
            help = "Turned back ON automatically when you leave, and before the phone restarts.",
            checked = s.turnDataOffOnWifi,
            onChange = { onChange(s.copy(turnDataOffOnWifi = it)) },
        )
        SwitchRow(
            title = "Only after Wi-Fi internet is validated",
            help = "Recommended: never leaves you on a Wi-Fi that has no internet.",
            checked = s.dataOffNeedsInternet,
            onChange = { onChange(s.copy(dataOffNeedsInternet = it)) },
        )
    }
}

@Composable
private fun SwitchRow(title: String, help: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(help, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun TuningCard(s: AutopilotSettings, onChange: (AutopilotSettings) -> Unit) {
    var grace by remember(s.graceSeconds) { mutableFloatStateOf(s.graceSeconds.toFloat()) }
    var interval by remember(s.scanIntervalMin) { mutableFloatStateOf(s.scanIntervalMin.toFloat()) }
    var rssi by remember(s.minRssi) { mutableFloatStateOf(s.minRssi.toFloat()) }
    SectionCard("Fine-tuning") {
        Text(
            "Wait before switching to mobile data: ${grace.roundToInt()} s",
            style = MaterialTheme.typography.bodyMedium,
        )
        Slider(
            value = grace,
            onValueChange = { grace = it },
            valueRange = 3f..30f,
            steps = 26,
            onValueChangeFinished = { onChange(s.copy(graceSeconds = grace.roundToInt())) },
        )
        Text(
            "Look for my networks every ${interval.roundToInt()} min (plus when you move, change cell tower or wake the screen)",
            style = MaterialTheme.typography.bodyMedium,
        )
        Slider(
            value = interval,
            onValueChange = { interval = it },
            valueRange = 1f..15f,
            steps = 13,
            onValueChangeFinished = { onChange(s.copy(scanIntervalMin = interval.roundToInt())) },
        )
        Text(
            "Turn Wi-Fi on only if the signal is at least ${rssi.roundToInt()} dBm (${signalWord(rssi.roundToInt())})",
            style = MaterialTheme.typography.bodyMedium,
        )
        Slider(
            value = rssi,
            onValueChange = { rssi = it },
            valueRange = -90f..-55f,
            steps = 6,
            onValueChangeFinished = { onChange(s.copy(minRssi = rssi.roundToInt())) },
        )
    }
}

private fun signalWord(dbm: Int): String = when {
    dbm >= -60 -> "strong"
    dbm >= -70 -> "good"
    dbm >= -80 -> "fair"
    else -> "weak"
}

@Composable
private fun TestCard(
    busy: Boolean,
    onLeave: () -> Unit,
    onArrive: () -> Unit,
    onScan: () -> Unit,
) {
    SectionCard("Try it", "Runs the same dual-engine controller the automation uses.") {
        Button(onClick = onLeave, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text("Simulate leaving: Wi-Fi OFF + mobile data ON")
        }
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = onArrive, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text("Simulate arriving: Wi-Fi ON")
        }
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = onScan, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text("Scan now for my networks")
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Tip: at home with automation ON, “Simulate leaving” is followed by Wi-Fi coming back on by itself " +
                "within a few seconds — that's the arrival rule working. If OriginOS asks whether Wi-Fi Autopilot " +
                "may turn on WLAN, choose Always allow.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun LogCard(entries: List<ActivityLog.Entry>, onClear: () -> Unit) {
    SectionCard("Activity log", "Newest first") {
        if (entries.isEmpty()) {
            Text(
                "Nothing yet. Automatic switches will show up here.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            entries.take(80).forEach { e ->
                Column(Modifier.padding(vertical = 5.dp)) {
                    Text(
                        formatTime(e.time),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(e.text, style = MaterialTheme.typography.bodyMedium)
                }
            }
            TextButton(onClick = onClear) { Text("Clear log") }
        }
    }
}

private fun formatTime(millis: Long): String {
    val then = Calendar.getInstance().apply { timeInMillis = millis }
    val now = Calendar.getInstance()
    val sameDay = then.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
        then.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
    val pattern = if (sameDay) "'Today' HH:mm:ss" else "d MMM, HH:mm:ss"
    return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(millis))
}
