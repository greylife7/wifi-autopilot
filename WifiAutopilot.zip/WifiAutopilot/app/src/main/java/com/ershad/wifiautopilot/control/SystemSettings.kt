package com.ershad.wifiautopilot.control

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.SystemClock
import android.provider.Settings
import com.ershad.wifiautopilot.core.ActivityLog
import com.ershad.wifiautopilot.core.Prefs

/**
 * Everything done with WRITE_SECURE_SETTINGS – granted once through Shizuku (or adb) and kept by
 * Android across reboots, so none of this needs Shizuku afterwards.
 */
object SystemSettings {

    private const val KEY_ALWAYS_ON = "mobile_data_always_on"

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    private fun readGlobal(ctx: Context, key: String, def: Int): Int =
        try { Settings.Global.getInt(ctx.contentResolver, key, def) } catch (e: Throwable) { def }

    private fun writeGlobal(ctx: Context, key: String, value: Int): Boolean =
        try { Settings.Global.putInt(ctx.contentResolver, key, value) } catch (e: Throwable) { false }

    /**
     * Re-applies the switches the automation relies on. Cheap; called at start-up and on unlock.
     * - wifi_scan_always_enabled = 1 → Android can scan while the Wi-Fi button is OFF
     * - wifi_wakeup_enabled = 1      → Android itself turns Wi-Fi ON near saved networks, even locked
     * - mobile_data_always_on = 0    → Android disconnects cellular data while Wi-Fi works
     * Returns a description of anything that had to be changed.
     */
    fun ensureSystemFlags(ctx: Context): List<String> {
        if (!hasPermission(ctx)) return emptyList()
        val changed = ArrayList<String>()
        if (readGlobal(ctx, "wifi_scan_always_enabled", 0) != 1 && writeGlobal(ctx, "wifi_scan_always_enabled", 1)) {
            changed += "Wi-Fi scanning ON"
        }
        if (readGlobal(ctx, "wifi_wakeup_enabled", 0) != 1 && writeGlobal(ctx, "wifi_wakeup_enabled", 1)) {
            changed += "Android auto Wi-Fi ON"
        }
        val alwaysOn = readGlobal(ctx, KEY_ALWAYS_ON, 1)
        if (alwaysOn != 0) {
            if (Prefs.previousAlwaysOn == -1) Prefs.previousAlwaysOn = alwaysOn
            if (writeGlobal(ctx, KEY_ALWAYS_ON, 0)) changed += "cellular pauses on Wi-Fi"
        }
        return changed
    }

    /** Puts "Mobile data always active" back the way it was before the app changed it. */
    fun restoreAlwaysOn(ctx: Context) {
        val prev = Prefs.previousAlwaysOn
        if (prev == -1 || !hasPermission(ctx)) return
        writeGlobal(ctx, KEY_ALWAYS_ON, prev)
        Prefs.previousAlwaysOn = -1
    }

    fun isWifiWakeOn(ctx: Context) = readGlobal(ctx, "wifi_wakeup_enabled", 0) == 1
    fun cellularPausesOnWifi(ctx: Context) = readGlobal(ctx, KEY_ALWAYS_ON, 1) == 0

    // ---------------------------------------------------------------- mobile data via Settings.Global

    /**
     * Writes the mobile-data value straight into Settings.Global.
     *
     * Stock Android 13–16 does NOT watch this value (its DataSettingsManager only writes and reads
     * it), and OriginOS may restrict it too – so on most phones nothing happens, and a stale value can
     * even make the Quick Settings switch stop responding. So: write, check for 4 s whether data really
     * changed, and if not, put the old value back and remember that this phone doesn't support it.
     */
    fun trySettingsDataSwitch(ctx: Context, on: Boolean): Boolean {
        if (!hasPermission(ctx)) return false
        val before = RadioState.isMobileDataOn(ctx) ?: return false
        if (before == on) return true
        val cr = ctx.contentResolver
        val key = RadioState.mobileDataKey(ctx)
        val old = try { Settings.Global.getInt(cr, key) } catch (e: Throwable) { null }
        if (!writeGlobal(ctx, key, if (on) 1 else 0)) return false
        val worked = waitUntil(4_000) { RadioState.isMobileDataOn(ctx) == on }
        if (!worked) writeGlobal(ctx, key, old ?: if (before) 1 else 0)
        val result = if (worked) 1 else -1
        if (Prefs.current.globalDataSwitch != result) {
            Prefs.update { it.copy(globalDataSwitch = result) }
            ActivityLog.add(
                if (worked) "Settings.Global mobile-data switch works on this phone"
                else "This phone ignores the Settings.Global mobile-data switch (normal on Android 13+) — undone"
            )
        }
        return worked
    }

    /** For the test button: tries the Settings.Global data switch both ways and reports. */
    fun testSettingsDataSwitch(ctx: Context): String {
        if (!hasPermission(ctx)) return "Needs the permanent permission first (run the permanent setup)."
        val start = RadioState.isMobileDataOn(ctx) ?: return "Can't read the mobile-data switch (no SIM?)."
        Prefs.update { it.copy(globalDataSwitch = 0) }
        if (!trySettingsDataSwitch(ctx, !start)) {
            return "Settings.Global data switch: NOT supported on this phone. Nothing was changed. " +
                "Mobile data stays on and Android pauses it while Wi-Fi works."
        }
        trySettingsDataSwitch(ctx, start)
        return "Settings.Global data switch: WORKS on this phone (silent, survives reboots)."
    }

    // ---------------------------------------------------------------- no accessibility service

    /*
     * Versions up to 3.1 had an accessibility service (the "tile switcher"). Banking apps such as
     * bKash refuse to run while a sideloaded app has one switched on. Version 4 has none. Android
     * drops the old entry by itself once the service is gone; this removes any leftover as well.
     */

    private fun enabledServices(ctx: Context): List<String> {
        val raw = try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        } catch (e: Throwable) {
            null
        } ?: return emptyList()
        return raw.split(':').map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun isOurs(ctx: Context, entry: String): Boolean =
        entry.startsWith(ctx.packageName + "/") ||
            ComponentName.unflattenFromString(entry)?.packageName == ctx.packageName

    /** Is an accessibility entry of this app (left over from version 3) still switched on? */
    fun hasOldAccessibilityEntry(ctx: Context): Boolean = enabledServices(ctx).any { isOurs(ctx, it) }

    /** Removes this app's leftover accessibility entry. Returns true only if something was removed. */
    fun removeOldAccessibilityEntry(ctx: Context): Boolean {
        if (!hasPermission(ctx)) return false
        val entries = enabledServices(ctx)
        val kept = entries.filterNot { isOurs(ctx, it) }
        if (kept.size == entries.size) return false
        return try {
            Settings.Secure.putString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, kept.joinToString(":"))
        } catch (e: Throwable) {
            false
        }
    }

    private inline fun waitUntil(timeoutMs: Long, condition: () -> Boolean): Boolean {
        val end = SystemClock.elapsedRealtime() + timeoutMs
        while (true) {
            if (condition()) return true
            if (SystemClock.elapsedRealtime() >= end) return false
            try {
                Thread.sleep(250)
            } catch (e: InterruptedException) {
                return condition()
            }
        }
    }
}
