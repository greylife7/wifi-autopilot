package com.ershad.wifiautopilot.core

import android.content.Context

/** getSystemService() that never returns null (these services always exist on a phone). */
inline fun <reified T : Any> Context.systemService(): T =
    requireNotNull(getSystemService(T::class.java)) { "System service ${T::class.java.simpleName} is unavailable" }
