package com.ershad.wifiautopilot.control

import android.content.Context
import android.net.wifi.WifiManager
import android.os.SystemClock
import com.ershad.wifiautopilot.core.Prefs
import com.ershad.wifiautopilot.core.systemService

/**
 * The DUAL-ENGINE CONTROLLER. Every Wi-Fi / mobile-data switch goes through here. Nothing in it
 * needs the screen, so everything works with the phone locked in your pocket. There is no
 * accessibility service, so banking apps (bKash and others) have nothing to object to.
 *
 * WI-FI
 *   1. Android's own switch, WifiManager.setWifiEnabled(). Android 10–16 still allow it for apps
 *      that target Android 9 (targetSdk 28), which this app does on purpose: silent, works while
 *      locked and after every reboot, no Shizuku.
 *   2. Shizuku (`cmd wifi set-wifi-enabled`), only if it happens to be running.
 *   (Arrivals have one more safety net: Android's own "Turn on Wi-Fi automatically".)
 *
 * MOBILE DATA – Android doesn't let normal apps flip this switch, so:
 *   1. Settings.Global mobile_data (WRITE_SECURE_SETTINGS, granted once) – used at runtime with no
 *      Shizuku, but only where this phone honours it (tested during the one-time setup and undone if
 *      it doesn't; stock Android 13–16 ignores it).
 *   2. Shizuku `svc data enable/disable` – a fallback only while Shizuku happens to be installed
 *      (for example during the one-time setup, before you uninstall it).
 *   When neither can switch the toggle, it stays on and Android still pauses mobile data by itself
 *   while Wi-Fi works (mobile_data_always_on = 0, set by the one-time setup) – so no data is used.
 */
object DualEngineController {

    enum class Outcome { DONE, FAILED }

    data class Result(val outcome: Outcome, val via: String) {
        val done: Boolean get() = outcome == Outcome.DONE
    }

    // Remembers our own last Wi-Fi command so the engine can tell "we switched it" from
    // "the user (or Android) switched it".
    @Volatile private var lastWifiCommandAt = 0L
    @Volatile private var lastWifiCommandOn = false

    fun wasOurWifiCommand(on: Boolean, withinMs: Long): Boolean =
        lastWifiCommandOn == on && SystemClock.elapsedRealtime() - lastWifiCommandAt < withinMs

    private fun noteWifiCommand(on: Boolean) {
        lastWifiCommandAt = SystemClock.elapsedRealtime()
        lastWifiCommandOn = on
    }

    /** True when Android lets this app switch Wi-Fi itself (it targets Android 9 / SDK 28). */
    fun canSwitchWifiNatively(ctx: Context): Boolean = ctx.applicationInfo.targetSdkVersion <= 28

    fun setWifi(ctx: Context, on: Boolean): Result {
        if (RadioState.isWifiOn(ctx) == on) return Result(Outcome.DONE, "already")
        var problem = "Android doesn't allow it"
        // ENGINE 1: Android's own Wi-Fi switch (silent, reboot-proof, works while locked)
        if (canSwitchWifiNatively(ctx)) {
            val wm: WifiManager = ctx.applicationContext.systemService()
            noteWifiCommand(on)
            @Suppress("DEPRECATION")
            val accepted = try { wm.setWifiEnabled(on) } catch (e: Throwable) { false }
            if (accepted && waitUntil(8_000) { RadioState.isWifiOn(ctx) == on }) {
                recordNativeResult(true)
                return Result(Outcome.DONE, "Android")
            }
            recordNativeResult(false)
            problem = if (accepted) "no change; allow “turn on WLAN” if OriginOS asks" else "Android refused"
        }
        // ENGINE 2: Shizuku, whenever it happens to be running
        if (ShizukuHelper.isReady()) {
            noteWifiCommand(on)
            ShizukuHelper.run("cmd wifi set-wifi-enabled " + if (on) "enabled" else "disabled")
            if (waitUntil(6_000) { RadioState.isWifiOn(ctx) == on }) return Result(Outcome.DONE, "Shizuku")
        }
        return Result(Outcome.FAILED, problem)
    }

    fun setMobileData(ctx: Context, on: Boolean): Result {
        val now = RadioState.isMobileDataOn(ctx)
        if (now == on) return Result(Outcome.DONE, "already")
        // ENGINE 1: Settings.Global with the permanent permission (only where the phone honours it)
        if (Prefs.current.globalDataSwitch != -1 && SystemSettings.trySettingsDataSwitch(ctx, on)) {
            return Result(Outcome.DONE, "Settings.Global")
        }
        // ENGINE 2: Shizuku (silent, works while locked)
        if (ShizukuHelper.isReady()) {
            val verb = if (on) "enable" else "disable"
            val first = ShizukuHelper.run("svc data $verb")
            if (now == null && first.ok) return Result(Outcome.DONE, "Shizuku")
            if (waitUntil(5_000) { RadioState.isMobileDataOn(ctx) == on }) return Result(Outcome.DONE, "Shizuku")
            ShizukuHelper.run("cmd phone data $verb")
            if (waitUntil(4_000) { RadioState.isMobileDataOn(ctx) == on }) return Result(Outcome.DONE, "Shizuku")
        }
        val reason = when {
            ShizukuHelper.isReady() -> "couldn't switch data"
            ShizukuHelper.isInstalled() -> "Shizuku isn't running"
            Prefs.current.globalDataSwitch == -1 -> "this phone keeps data on; Android pauses it on Wi-Fi"
            else -> "finish the one-time setup first"
        }
        return Result(Outcome.FAILED, reason)
    }

    /** Automation switched off: hand back a mobile-data switch this app had turned OFF. Blocking. */
    fun restoreMobileData(ctx: Context) {
        if (!Prefs.dataOffByApp) return
        if (RadioState.isMobileDataOn(ctx) == false) setMobileData(ctx, true)
        if (RadioState.isMobileDataOn(ctx) != false) Prefs.dataOffByApp = false
    }

    private fun recordNativeResult(worked: Boolean) {
        val value = if (worked) 1 else -1
        if (Prefs.current.wifiSwitch != value) Prefs.update { it.copy(wifiSwitch = value) }
    }

    private inline fun waitUntil(timeoutMs: Long, condition: () -> Boolean): Boolean {
        val end = SystemClock.elapsedRealtime() + timeoutMs
        while (true) {
            if (condition()) return true
            if (SystemClock.elapsedRealtime() >= end) return false
            try {
                Thread.sleep(250)
            } catch (e: InterruptedException) {
                return condition()
            }
        }
    }
}
