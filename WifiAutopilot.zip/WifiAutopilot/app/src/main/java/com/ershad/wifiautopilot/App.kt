package com.ershad.wifiautopilot

import android.app.Application
import com.ershad.wifiautopilot.control.ShizukuHelper
import com.ershad.wifiautopilot.control.SystemSettings
import com.ershad.wifiautopilot.core.ActivityLog
import com.ershad.wifiautopilot.core.Notifications
import com.ershad.wifiautopilot.core.Prefs

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        ActivityLog.init(this)
        Notifications.createChannels(this)
        ShizukuHelper.init(this)
        // Version 4 has no accessibility service; make sure no entry from version 3 is left behind.
        SystemSettings.removeOldAccessibilityEntry(this)
    }
}
