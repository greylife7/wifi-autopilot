package com.ershad.wifiautopilot.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.TriggerEvent
import android.hardware.TriggerEventListener
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.telephony.CellLocation
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import com.ershad.wifiautopilot.control.DualEngineController
import com.ershad.wifiautopilot.control.RadioState
import com.ershad.wifiautopilot.control.ShizukuHelper
import com.ershad.wifiautopilot.control.SystemSettings
import com.ershad.wifiautopilot.core.ActivityLog
import com.ershad.wifiautopilot.core.Notifications
import com.ershad.wifiautopilot.core.Prefs
import com.ershad.wifiautopilot.core.systemService
import java.util.concurrent.Executor

/**
 * The automation rules. Lives inside [AutomationForegroundService] and does all its work on one
 * background thread, so events are handled strictly one at a time. Event-driven: no polling loop.
 *
 * 1. LEAVING – Wi-Fi disconnected for the grace period (5 s):
 *      Wi-Fi OFF, mobile data ON.
 * 2. ARRIVING – Wi-Fi is OFF and a saved SSID shows up in Android's background scans:
 *      Wi-Fi ON; once NET_CAPABILITY_VALIDATED arrives over TRANSPORT_WIFI → mobile data OFF.
 *
 * Every switch goes through [DualEngineController]: Wi-Fi with Android's own switch (the app
 * targets SDK 28 for this), mobile data with Settings.Global using the permanent permission granted
 * once through Shizuku (no Shizuku needed afterwards). All of it works with the phone locked; there
 * is no accessibility service. Before the phone switches off, mobile data goes back ON so a restart
 * never leaves you without data. Android's own "Turn on Wi-Fi automatically" (enabled by the
 * one-time setup and fed by this app's scans) is an extra safety net for arrivals.
 *
 * It reacts to *changes* only, so it never fights a switch you flip by hand; if you turn Wi-Fi off
 * yourself near a saved network, it stays off until you have left that place.
 *
 * Looking for saved networks happens only while Wi-Fi is off, cheapest trigger first: scans that
 * Android already did (free) → significant-motion sensor → cell-tower change → screen on/unlock →
 * a gentle timer (every N minutes, batched by Android while the phone sleeps).
 */
class AutomationEngine(private val app: Context) {

    private companion object {
        const val GRACE_EXTRA_AWAKE_MS = 8_000L
        const val CONNECT_TIMEOUT_MS = 60_000L
        const val CONNECT_FAIL_COOLDOWN_MS = 10 * 60_000L
        const val BASE_COOLDOWN_MS = 2 * 60_000L
        const val MAX_COOLDOWN_MS = 30 * 60_000L
        const val FLAP_WINDOW_MS = 5 * 60_000L
        const val STABLE_CONNECTION_MS = 10 * 60_000L
        const val SCAN_WAIT_MS = 6_000L
        const val MIN_ACTIVE_SCAN_GAP_MS = 30_000L // Android allows ~4 app scans per 2 minutes
        const val MIN_TRIGGER_SCAN_GAP_MS = 45_000L
        const val OWN_COMMAND_WINDOW_MS = 20_000L
        const val SNOOZE_RELEASE_MISSES = 3
        const val PENDING_WIFI_ON_MAX_AGE_MS = 10 * 60_000L
        const val SHIZUKU_BOOT_GRACE_MS = 4 * 60_000L
        const val ALARM_REQUEST_CODE = 7001
        const val ACTION_QUICKBOOT_POWEROFF = "android.intent.action.QUICKBOOT_POWEROFF"

        // Hotspot broadcast (system constants that aren't in the public SDK)
        const val ACTION_WIFI_AP_STATE_CHANGED = "android.net.wifi.WIFI_AP_STATE_CHANGED"
        const val EXTRA_WIFI_AP_STATE = "wifi_state"
        const val WIFI_AP_STATE_ENABLING = 12
        const val WIFI_AP_STATE_ENABLED = 13
    }

    private val thread = HandlerThread("autopilot-engine").apply { start() }
    private val handler = Handler(thread.looper)
    private val engineExecutor = Executor { handler.post(it) }

    private val cm: ConnectivityManager = app.systemService()
    private val wm: WifiManager = app.applicationContext.systemService()
    private val alarms: AlarmManager = app.systemService()
    private val sensors: SensorManager = app.systemService()
    private val telephony: TelephonyManager? = app.getSystemService(TelephonyManager::class.java)
    private val wakeLock = app.systemService<PowerManager>()
        .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WifiAutopilot:engine")
        .apply { setReferenceCounted(false) }
    private val awakeLock = Any()
    private var awakeUntil = 0L

    // ----- state: only touched on the engine thread -----
    private var running = false
    private val wifiNetworks = HashMap<Network, NetworkCapabilities>()
    private var wifiConnected = false
    private var wifiInternet = false
    private var currentSsid: String? = null
    private var lastSsid: String? = null
    private var connectedSince = 0L
    private var hotspotOn = false
    private var watching = false
    private var autoOnPending = false
    private var lastAutoOnAt = 0L
    private var cooldownUntil = 0L
    private var flapCount = 0
    private val snoozed = HashMap<String, Int>() // lower-case SSID -> scans in a row it was missing
    private var lastScanKey = Long.MIN_VALUE
    private var lastActiveScanAt = 0L
    private var lastTriggerScanAt = 0L
    private var motionArmed = false
    private var cellListening = false
    private var shizukuWasReady = false

    // Switches that didn't work (for example while OriginOS waited for a permission answer);
    // tried again when you unlock or when Shizuku shows up.
    private var pendingWifiOff = false
    private var pendingWifiOnAt = 0L
    private var pendingDataOn = false

    private val graceRunnable = Runnable { onGraceExpired() }
    private val connectTimeoutRunnable = Runnable { onConnectTimeout() }
    private val evaluateRunnable = Runnable { evaluateScan() }
    private val rearmMotionRunnable = Runnable { if (watching) armMotion() }
    private val shizukuNudgeRunnable = Runnable { maybeAskToStartShizuku() }

    // ================================================================= lifecycle

    fun start() {
        handler.post { startInternal() }
    }

    fun stop() {
        handler.post {
            stopInternal()
            thread.quitSafely()
        }
    }

    /** Called by the UI after settings or the saved-network list change. */
    fun onSettingsChanged() {
        handler.post {
            if (!running) return@post
            val wasWatching = watching
            updateWatchMode()
            if (wasWatching && watching) {
                cancelAlarm()
                scheduleAlarm()
                handler.postDelayed({ requestActiveScan() }, 1_000)
            }
            pushStatus()
        }
    }

    /** Called by [AlarmReceiver]. */
    fun onAlarm() {
        keepAwake(SCAN_WAIT_MS + 6_000)
        handler.post {
            if (!running || !watching) return@post
            scheduleAlarm()
            requestActiveScan()
        }
    }

    private fun startInternal() {
        if (running) return
        running = true
        registerReceivers()
        cm.registerNetworkCallback(
            NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build(),
            networkCallback,
            handler,
        )
        ShizukuHelper.addReadyListener(shizukuListener)
        shizukuWasReady = ShizukuHelper.isReady()

        val engines = buildList {
            if (DualEngineController.canSwitchWifiNatively(app)) add("Android Wi-Fi switch")
            if (Prefs.current.globalDataSwitch == 1) add("Settings.Global data")
            if (shizukuWasReady) add("Shizuku")
        }
        ActivityLog.add(
            "Automation started (" + (if (engines.isEmpty()) "no engine yet — finish Setup" else engines.joinToString(" + ")) + ")"
        )
        maintainSystem()
        handler.postDelayed({ initialSync() }, 2_000)
        updateWatchMode()
        pushStatus()
    }

    private fun stopInternal() {
        if (!running) return
        running = false
        try { app.unregisterReceiver(receiver) } catch (e: Exception) { }
        try { cm.unregisterNetworkCallback(networkCallback) } catch (e: Exception) { }
        ShizukuHelper.removeReadyListener(shizukuListener)
        disarmMotion()
        stopCellListener()
        cancelAlarm()
        handler.removeCallbacksAndMessages(null)
        synchronized(awakeLock) {
            if (wakeLock.isHeld) wakeLock.release()
            awakeUntil = 0L
        }
        Notifications.cancelStatus(app)
    }

    /** Keeps the permanent system switches in place and makes sure no old accessibility entry is left. */
    private fun maintainSystem() {
        val fixed = SystemSettings.ensureSystemFlags(app)
        if (fixed.isNotEmpty()) ActivityLog.add("Re-applied: " + fixed.joinToString(", "))
        if (SystemSettings.removeOldAccessibilityEntry(app)) {
            ActivityLog.add("Removed the old accessibility entry from version 3 (banking apps check for it)")
        }
    }

    /** On start (and when an engine comes back) bring the radios in line with the rules once. */
    private fun initialSync() {
        val s = Prefs.current
        if (!running || !s.automationOn || isAirplaneOn()) return
        when {
            wifiConnected -> if (wifiInternet || !s.dataOffNeedsInternet) onWifiUsable()
            wm.isWifiEnabled -> if (!autoOnPending) armConnectTimeout() // on but not connected: give it a minute
            else -> ensureMobileDataOn("Wi-Fi is off")
        }
        pushStatus()
    }

    // ================================================================= Wi-Fi connection events

    private val networkCallback =
        object : ConnectivityManager.NetworkCallback(ConnectivityManager.NetworkCallback.FLAG_INCLUDE_LOCATION_INFO) {
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                wifiNetworks[network] = networkCapabilities
                onWifiNetworksChanged()
            }

            override fun onLost(network: Network) {
                wifiNetworks.remove(network)
                onWifiNetworksChanged()
            }
        }

    private fun onWifiNetworksChanged() {
        val connected = wifiNetworks.isNotEmpty()
        val internet = wifiNetworks.values.any { it.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) }
        val ssid = if (connected) {
            wifiNetworks.values.firstNotNullOfOrNull { RadioState.cleanSsid((it.transportInfo as? WifiInfo)?.ssid) }
                ?: RadioState.connectedSsid(app)
        } else {
            null
        }
        val wasConnected = wifiConnected
        val hadInternet = wifiInternet
        wifiConnected = connected
        wifiInternet = internet
        if (connected && ssid != null) currentSsid = ssid

        if (connected && !wasConnected) onWifiConnected()
        if (!connected && wasConnected) onWifiDisconnected()
        if (connected && internet && !hadInternet && Prefs.current.dataOffNeedsInternet) onWifiUsable()
        pushStatus()
    }

    private fun onWifiConnected() {
        handler.removeCallbacks(graceRunnable)
        if (autoOnPending) {
            autoOnPending = false
            handler.removeCallbacks(connectTimeoutRunnable)
        }
        pendingWifiOff = false
        pendingDataOn = false
        pendingWifiOnAt = 0L
        connectedSince = SystemClock.elapsedRealtime()
        lastSsid = currentSsid
        snoozed.clear()
        Notifications.clearDataOffAlert(app)
        ActivityLog.add("Connected to ${quote(currentSsid)}")
        if (!Prefs.current.dataOffNeedsInternet) onWifiUsable()
        updateWatchMode()
    }

    /**
     * ARRIVING, step B: Wi-Fi is connected (and by default validated) → mobile data OFF, via
     * Settings.Global where this phone honours it. Where it doesn't, the switch stays on but Android
     * pauses mobile data by itself (mobile_data_always_on = 0), so no data is used on Wi-Fi.
     */
    private fun onWifiUsable() {
        val s = Prefs.current
        if (!running || !s.automationOn || isAirplaneOn()) return
        SystemSettings.ensureSystemFlags(app)
        if (!s.turnDataOffOnWifi || RadioState.isMobileDataOn(app) != true) {
            pushStatus()
            return
        }
        val r = DualEngineController.setMobileData(app, false)
        if (r.done) {
            Prefs.dataOffByApp = true
            Notifications.clearShizukuAlert(app)
            ActivityLog.add("Wi-Fi ${quote(currentSsid)} works → mobile data OFF (${r.via})")
        } else {
            ActivityLog.add("Wi-Fi ${quote(currentSsid)} works → ${pausedCellularText()} (${r.via})")
            maybeAskToStartShizuku()
        }
        pushStatus()
    }

    /**
     * Only relevant while Shizuku is still installed (for example during the one-time setup): if the
     * data switch isn't supported on this phone and Shizuku is installed but not running, nudge to
     * start it. Does nothing once Shizuku is uninstalled.
     */
    private fun maybeAskToStartShizuku() {
        handler.removeCallbacks(shizukuNudgeRunnable)
        val s = Prefs.current
        if (!running || !s.automationOn || !s.turnDataOffOnWifi || !wifiConnected) return
        if (s.globalDataSwitch == 1 || ShizukuHelper.isReady() || !ShizukuHelper.isInstalled()) return
        if (RadioState.isMobileDataOn(app) != true) return
        val sinceBoot = SystemClock.elapsedRealtime()
        if (sinceBoot < SHIZUKU_BOOT_GRACE_MS) {
            handler.postDelayed(shizukuNudgeRunnable, SHIZUKU_BOOT_GRACE_MS - sinceBoot + 1_000)
            return
        }
        Notifications.alertStartShizuku(app)
    }

    /**
     * The phone is switching off or restarting. A mobile-data switch this app turned OFF goes back
     * ON now, so the phone always starts with working mobile data; the automation turns it off again
     * once you're on Wi-Fi. (Where Settings.Global works it also works right after a reboot, so
     * nothing needs doing in that case.)
     */
    private fun onShutdown() {
        if (!Prefs.dataOffByApp) return
        if (RadioState.isMobileDataOn(app) != false) {
            Prefs.dataOffByApp = false
            return
        }
        if (Prefs.current.globalDataSwitch == 1) return // Settings.Global works right after a reboot too
        if (!ShizukuHelper.isReady()) return
        ShizukuHelper.run("svc data enable", 3_000)
        Prefs.dataOffByApp = false
        ActivityLog.add("Phone switching off → mobile data back ON so it works straight after the restart")
    }

    private fun onWifiDisconnected() {
        if (SystemClock.elapsedRealtime() - connectedSince >= STABLE_CONNECTION_MS) flapCount = 0
        lastSsid = currentSsid ?: lastSsid
        currentSsid = null
        if (Prefs.current.automationOn) scheduleGrace()
    }

    private fun scheduleGrace() {
        val ms = Prefs.current.graceSeconds * 1000L
        handler.removeCallbacks(graceRunnable)
        keepAwake(ms + GRACE_EXTRA_AWAKE_MS)
        handler.postDelayed(graceRunnable, ms)
    }

    /** LEAVING: still no Wi-Fi after the grace period → Wi-Fi OFF, mobile data ON. */
    private fun onGraceExpired() {
        val s = Prefs.current
        if (!running || !s.automationOn || wifiConnected || isAirplaneOn()) return
        val done = ArrayList<String>()
        if (wm.isWifiEnabled && !hotspotOn && !autoOnPending) {
            val r = DualEngineController.setWifi(app, false)
            if (r.done) {
                pendingWifiOff = false
                done += "Wi-Fi OFF (${r.via})"
                armCooldownAfterAutoOff()
            } else {
                pendingWifiOff = true
                done += "Wi-Fi stays on for now (${r.via})"
                Notifications.alertCantSwitch(app, "Wi-Fi couldn't be switched off (${r.via}).")
            }
        }
        when (RadioState.isMobileDataOn(app)) {
            true -> {
                Prefs.dataOffByApp = false
                done += "mobile data ON"
            }
            false -> {
                val r = DualEngineController.setMobileData(app, true)
                if (r.done) {
                    pendingDataOn = false
                    Prefs.dataOffByApp = false
                    done += "mobile data ON (${r.via})"
                } else {
                    pendingDataOn = true
                    done += "the mobile-data switch is OFF — tap the notification"
                    Notifications.alertDataOff(app)
                }
            }
            null -> Unit
        }
        if (done.isNotEmpty()) {
            val where = lastSsid?.let { "Left ${quote(it)}" } ?: "Wi-Fi disconnected"
            ActivityLog.add("$where (${s.graceSeconds}s) → ${done.joinToString(", ")}")
        }
        updateWatchMode()
        pushStatus()
    }

    /** Makes sure mobile data is usable when there's no Wi-Fi. */
    private fun ensureMobileDataOn(reason: String) {
        if (RadioState.isMobileDataOn(app) != false) return
        val r = DualEngineController.setMobileData(app, true)
        if (r.done) {
            pendingDataOn = false
            Prefs.dataOffByApp = false
            ActivityLog.add("$reason → mobile data ON (${r.via})")
        } else {
            pendingDataOn = true
            ActivityLog.add("$reason and the mobile-data switch is OFF → tap the notification to switch it on")
            Notifications.alertDataOff(app)
        }
    }

    /** Short pause before Wi-Fi may come back on, growing if we keep flip-flopping at the edge of range. */
    private fun armCooldownAfterAutoOff() {
        val now = SystemClock.elapsedRealtime()
        flapCount = if (lastAutoOnAt != 0L && now - lastAutoOnAt < FLAP_WINDOW_MS) (flapCount + 1).coerceAtMost(4) else 0
        cooldownUntil = now + (BASE_COOLDOWN_MS shl flapCount).coerceAtMost(MAX_COOLDOWN_MS)
    }

    // ================================================================= unlock: try again what didn't work

    private fun onUnlock() {
        if (!running) return
        maintainSystem()
        runPending()
        if (watching) requestActiveScan()
    }

    private fun runPending() {
        val s = Prefs.current
        if (!running || !s.automationOn || isAirplaneOn()) return
        val now = SystemClock.elapsedRealtime()

        if (pendingWifiOff) {
            if (wifiConnected || !wm.isWifiEnabled || hotspotOn) {
                pendingWifiOff = false
            } else {
                val r = DualEngineController.setWifi(app, false)
                if (r.done) {
                    pendingWifiOff = false
                    armCooldownAfterAutoOff()
                    ActivityLog.add("Tried again: Wi-Fi OFF (${r.via})")
                }
            }
        }
        if (pendingDataOn) {
            if (wifiConnected || RadioState.isMobileDataOn(app) != false) {
                pendingDataOn = false
                Notifications.clearDataOffAlert(app)
            } else {
                val r = DualEngineController.setMobileData(app, true)
                if (r.done) {
                    pendingDataOn = false
                    Prefs.dataOffByApp = false
                    Notifications.clearDataOffAlert(app)
                    ActivityLog.add("Tried again: mobile data ON (${r.via})")
                }
            }
        }
        if (pendingWifiOnAt != 0L) {
            if (wm.isWifiEnabled || now - pendingWifiOnAt > PENDING_WIFI_ON_MAX_AGE_MS) {
                pendingWifiOnAt = 0L
            } else {
                // Decide again on a fresh scan rather than trusting an old one.
                pendingWifiOnAt = 0L
                cooldownUntil = 0L
                lastActiveScanAt = 0L
                requestActiveScan()
            }
        }
        pushStatus()
    }

    // ================================================================= Wi-Fi radio on/off events

    private fun onWifiRadioChanged(on: Boolean) {
        pendingWifiOff = false
        if (on) {
            pendingWifiOnAt = 0L
            snoozed.clear()
            if (!DualEngineController.wasOurWifiCommand(on = true, withinMs = OWN_COMMAND_WINDOW_MS) &&
                Prefs.current.automationOn && !wifiConnected
            ) {
                ActivityLog.add("Wi-Fi switched on (by Android's auto Wi-Fi or by you)")
            }
        } else {
            if (autoOnPending) {
                autoOnPending = false
                handler.removeCallbacks(connectTimeoutRunnable)
            }
            val byUs = DualEngineController.wasOurWifiCommand(on = false, withinMs = OWN_COMMAND_WINDOW_MS)
            if (!byUs && Prefs.current.automationOn) {
                // You switched Wi-Fi off yourself: respect it while you're still near these networks.
                val nearby = savedNetworksVisibleNow()
                snoozed.clear()
                nearby.forEach { snoozed[it.lowercase()] = 0 }
                if (nearby.isNotEmpty()) {
                    ActivityLog.add("You turned Wi-Fi off near ${nearby.joinToString { quote(it) }} — it stays off until you leave")
                }
                if (!wifiConnected) scheduleGrace() // makes sure mobile data comes on
            }
        }
        updateWatchMode()
        pushStatus()
    }

    // ================================================================= ARRIVING: looking for saved networks

    private fun updateWatchMode() {
        val s = Prefs.current
        val shouldWatch = running && s.automationOn && s.savedSsids.isNotEmpty() && !wm.isWifiEnabled
        if (shouldWatch == watching) {
            if (watching && !motionArmed) armMotion()
            return
        }
        watching = shouldWatch
        if (watching) {
            armMotion()
            startCellListener()
            scheduleAlarm()
            handler.postDelayed({ requestActiveScan() }, 4_000)
        } else {
            disarmMotion()
            stopCellListener()
            cancelAlarm()
            handler.removeCallbacks(evaluateRunnable)
        }
    }

    private fun requestActiveScan() {
        if (!running || !watching) return
        val now = SystemClock.elapsedRealtime()
        if (now < cooldownUntil) return
        if (now - lastActiveScanAt < MIN_ACTIVE_SCAN_GAP_MS) return
        lastActiveScanAt = now
        keepAwake(SCAN_WAIT_MS + 6_000)
        RadioState.startScan(app) // its results also feed Android's own auto Wi-Fi
        handler.removeCallbacks(evaluateRunnable)
        handler.postDelayed(evaluateRunnable, SCAN_WAIT_MS) // in case no "results ready" broadcast arrives
    }

    private fun evaluateScan() {
        if (!running || !watching || wm.isWifiEnabled) return
        val s = Prefs.current
        if (isAirplaneOn() || hotspotOn) return
        val snap = RadioState.readScan(app) ?: return
        if (snap.key == lastScanKey) return // nothing new since last time
        lastScanKey = snap.key

        // Strongest signal per saved network that is visible right now
        val savedByKey = s.savedSsids.associateBy { it.trim().lowercase() }
        val best = HashMap<String, Int>()
        for (r in snap.results) {
            val k = r.ssid.trim().lowercase()
            if (k in savedByKey) best[k] = maxOf(best[k] ?: Int.MIN_VALUE, r.rssi)
        }

        // A network you switched Wi-Fi off at is released once it has been gone for a few scans
        val iter = snoozed.entries.iterator()
        while (iter.hasNext()) {
            val e = iter.next()
            if (e.key in best) {
                e.setValue(0)
            } else {
                e.setValue(e.value + 1)
                if (e.value >= SNOOZE_RELEASE_MISSES) iter.remove()
            }
        }

        val candidate = best.entries
            .filter { e -> e.value >= s.minRssi && e.key !in snoozed }
            .maxByOrNull { e -> e.value } ?: return
        val now = SystemClock.elapsedRealtime()
        if (now < cooldownUntil) return

        val name = snap.results.firstOrNull { r -> r.ssid.trim().lowercase() == candidate.key }?.ssid?.trim()
            ?: savedByKey[candidate.key] ?: candidate.key
        lastAutoOnAt = now
        val r = DualEngineController.setWifi(app, true)
        if (r.done) {
            pendingWifiOnAt = 0L
            ActivityLog.add("Found ${quote(name)} nearby (${candidate.value} dBm) → Wi-Fi ON (${r.via})")
            armConnectTimeout()
        } else {
            if (pendingWifiOnAt == 0L) {
                ActivityLog.add(
                    "Found ${quote(name)} nearby (${candidate.value} dBm) but Wi-Fi didn't switch on (${r.via}); " +
                        "Android's auto Wi-Fi may still do it"
                )
                Notifications.alertCantSwitch(app, "Wi-Fi couldn't be switched on (${r.via}).")
            }
            pendingWifiOnAt = now
            cooldownUntil = now + BASE_COOLDOWN_MS
        }
        updateWatchMode()
        pushStatus()
    }

    private fun armConnectTimeout() {
        autoOnPending = true
        keepAwake(CONNECT_TIMEOUT_MS + 5_000)
        handler.removeCallbacks(connectTimeoutRunnable)
        handler.postDelayed(connectTimeoutRunnable, CONNECT_TIMEOUT_MS)
    }

    /** Wi-Fi was switched on but never connected → back off, use mobile data, try again later. */
    private fun onConnectTimeout() {
        if (!autoOnPending) return
        autoOnPending = false
        if (!running || wifiConnected || !Prefs.current.automationOn) return
        if (wm.isWifiEnabled) {
            val r = DualEngineController.setWifi(app, false)
            if (r.done) {
                cooldownUntil = SystemClock.elapsedRealtime() + CONNECT_FAIL_COOLDOWN_MS
                ActivityLog.add("Wi-Fi didn't connect within 60 s → Wi-Fi OFF again (${r.via}; next try in 10 min)")
            } else {
                pendingWifiOff = true
            }
        }
        ensureMobileDataOn("No Wi-Fi")
        updateWatchMode()
        pushStatus()
    }

    private fun savedNetworksVisibleNow(): List<String> {
        val saved = Prefs.current.savedSsids
        if (saved.isEmpty()) return emptyList()
        val seen = RadioState.readScan(app)?.results?.map { it.ssid.trim() } ?: return emptyList()
        return saved.filter { name -> seen.any { it.equals(name.trim(), ignoreCase = true) } }
    }

    // ================================================================= triggers

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                WifiManager.WIFI_STATE_CHANGED_ACTION -> {
                    if (isInitialStickyBroadcast) return
                    when (intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE, WifiManager.WIFI_STATE_UNKNOWN)) {
                        WifiManager.WIFI_STATE_ENABLED -> onWifiRadioChanged(true)
                        WifiManager.WIFI_STATE_DISABLED -> onWifiRadioChanged(false)
                    }
                }
                WifiManager.SCAN_RESULTS_AVAILABLE_ACTION -> if (watching) evaluateScan()
                Intent.ACTION_USER_PRESENT -> {
                    keepAwake(SCAN_WAIT_MS + 10_000)
                    onUnlock()
                }
                Intent.ACTION_SCREEN_ON -> if (watching) {
                    keepAwake(SCAN_WAIT_MS + 6_000)
                    requestActiveScan()
                }
                ACTION_WIFI_AP_STATE_CHANGED -> {
                    val st = intent.getIntExtra(EXTRA_WIFI_AP_STATE, 0)
                    hotspotOn = st == WIFI_AP_STATE_ENABLED || st == WIFI_AP_STATE_ENABLING
                }
                Intent.ACTION_AIRPLANE_MODE_CHANGED -> pushStatus()
                Intent.ACTION_SHUTDOWN, ACTION_QUICKBOOT_POWEROFF -> onShutdown()
            }
        }
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply {
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(ACTION_WIFI_AP_STATE_CHANGED)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(Intent.ACTION_SHUTDOWN)
            addAction(ACTION_QUICKBOOT_POWEROFF)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            app.registerReceiver(receiver, filter, null, handler, Context.RECEIVER_EXPORTED)
        } else {
            app.registerReceiver(receiver, filter, null, handler)
        }
    }

    // Significant motion: a low-power hardware sensor that fires when you start walking or driving.
    private val significantMotion: Sensor? = sensors.getDefaultSensor(Sensor.TYPE_SIGNIFICANT_MOTION)

    private val motionListener = object : TriggerEventListener() {
        override fun onTrigger(event: TriggerEvent?) {
            keepAwake(SCAN_WAIT_MS + 8_000)
            handler.post {
                motionArmed = false
                onMovementHint()
            }
        }
    }

    private fun armMotion() {
        val sensor = significantMotion ?: return
        if (!motionArmed) motionArmed = try { sensors.requestTriggerSensor(motionListener, sensor) } catch (e: Exception) { false }
    }

    private fun disarmMotion() {
        handler.removeCallbacks(rearmMotionRunnable)
        val sensor = significantMotion ?: return
        if (motionArmed) {
            try { sensors.cancelTriggerSensor(motionListener, sensor) } catch (e: Exception) { }
            motionArmed = false
        }
    }

    // Cell-tower change: the phone moved to another cell, so nearby Wi-Fi may have changed too.
    @Suppress("DEPRECATION")
    private val cellCallback = object : TelephonyCallback(), TelephonyCallback.CellLocationListener {
        override fun onCellLocationChanged(location: CellLocation) {
            keepAwake(SCAN_WAIT_MS + 8_000)
            onMovementHint()
        }
    }

    private fun startCellListener() {
        if (cellListening) return
        val tm = telephony ?: return
        cellListening = try {
            tm.registerTelephonyCallback(engineExecutor, cellCallback)
            true
        } catch (e: Exception) {
            false // needs location permission; the other triggers still work
        }
    }

    private fun stopCellListener() {
        if (!cellListening) return
        try { telephony?.unregisterTelephonyCallback(cellCallback) } catch (e: Exception) { }
        cellListening = false
    }

    /** Motion or a new cell tower: worth a fresh look, at most every 45 s. */
    private fun onMovementHint() {
        if (!running || !watching) return
        val now = SystemClock.elapsedRealtime()
        val sinceLast = now - lastTriggerScanAt
        if (sinceLast >= MIN_TRIGGER_SCAN_GAP_MS) {
            lastTriggerScanAt = now
            requestActiveScan()
            armMotion()
        } else {
            handler.removeCallbacks(rearmMotionRunnable)
            handler.postDelayed(rearmMotionRunnable, MIN_TRIGGER_SCAN_GAP_MS - sinceLast)
        }
    }

    private fun alarmIntent(): PendingIntent = PendingIntent.getBroadcast(
        app, ALARM_REQUEST_CODE, Intent(app, AlarmReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    private fun scheduleAlarm() {
        val at = SystemClock.elapsedRealtime() + Prefs.current.scanIntervalMin * 60_000L
        val pi = alarmIntent()
        try {
            if (alarms.canScheduleExactAlarms()) {
                alarms.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi)
            } else {
                alarms.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            alarms.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi)
        }
    }

    private fun cancelAlarm() {
        try { alarms.cancel(alarmIntent()) } catch (e: Exception) { }
    }

    // ================================================================= Shizuku coming and going

    private val shizukuListener: (Boolean) -> Unit = { ready -> handler.post { onShizukuChanged(ready) } }

    private fun onShizukuChanged(ready: Boolean) {
        if (!running || ready == shizukuWasReady) return
        shizukuWasReady = ready
        if (ready) {
            ActivityLog.add("Shizuku connected — mobile data can be switched")
            Notifications.clearAlert(app)
            Notifications.clearShizukuAlert(app)
            handler.removeCallbacks(shizukuNudgeRunnable)
            runPending()
            handler.postDelayed({ initialSync() }, 1_000)
        } else {
            ActivityLog.add("Shizuku stopped or uninstalled — Wi-Fi switching still works; mobile data uses the permanent permission")
            if (Prefs.dataOffByApp && RadioState.isMobileDataOn(app) == false && Prefs.current.globalDataSwitch != 1 && ShizukuHelper.isInstalled()) {
                Notifications.alertStartShizuku(app, dataIsOff = true)
            }
        }
        pushStatus()
    }

    // ================================================================= helpers

    private fun pushStatus() {
        if (!running) return
        val wifiText = when {
            wifiConnected -> "Wi-Fi: " + (currentSsid ?: "connected")
            wm.isWifiEnabled -> "Wi-Fi: on, connecting…"
            else -> "Wi-Fi: off"
        }
        val dataText = when (RadioState.isMobileDataOn(app)) {
            true -> if (wifiConnected && !RadioState.isCellularDataActive(app)) "Data: paused" else "Data: on"
            false -> "Data: off"
            null -> "Data: ?"
        }
        val extra = when {
            isAirplaneOn() -> " • Airplane mode"
            pendingDataOn -> " • data switch is off"
            pendingWifiOff -> " • couldn't switch Wi-Fi off"
            else -> ""
        }
        Notifications.updateStatus(app, "$wifiText • $dataText$extra")
    }

    /** Keeps the CPU awake for a short critical window (timers don't run while the phone sleeps). */
    private fun keepAwake(ms: Long) {
        synchronized(awakeLock) {
            val until = SystemClock.elapsedRealtime() + ms
            if (until > awakeUntil) {
                awakeUntil = until
                wakeLock.acquire(ms)
            }
        }
    }

    private fun isAirplaneOn(): Boolean = try {
        Settings.Global.getInt(app.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    } catch (e: Exception) {
        false
    }

    private fun quote(name: String?): String = if (name.isNullOrBlank()) "Wi-Fi" else "“$name”"

    private fun pausedCellularText(): String =
        if (SystemSettings.cellularPausesOnWifi(app)) {
            "mobile data paused by Android (no data used on Wi-Fi)"
        } else {
            "mobile data stays on (run the permanent setup so Android pauses it on Wi-Fi)"
        }
}
