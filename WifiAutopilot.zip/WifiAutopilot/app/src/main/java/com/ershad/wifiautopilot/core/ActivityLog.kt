package com.ershad.wifiautopilot.core

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

/** The "Activity log" shown in the app: newest first, kept on disk across restarts. */
object ActivityLog {
    data class Entry(val time: Long, val text: String)

    private const val MAX_ENTRIES = 200
    private lateinit var file: File
    private val _entries = MutableStateFlow<List<Entry>>(emptyList())
    val entries: StateFlow<List<Entry>> = _entries.asStateFlow()

    fun init(context: Context) {
        // Device-protected storage so logging works right after a reboot, before unlock.
        file = File(context.createDeviceProtectedStorageContext().filesDir, "activity_log.tsv")
        _entries.value = read()
    }

    @Synchronized
    fun add(text: String) {
        Log.i("WifiAutopilot", text)
        val list = (listOf(Entry(System.currentTimeMillis(), text)) + _entries.value).take(MAX_ENTRIES)
        _entries.value = list
        write(list)
    }

    @Synchronized
    fun clear() {
        _entries.value = emptyList()
        write(emptyList())
    }

    private fun write(list: List<Entry>) {
        try {
            file.writeText(list.joinToString("\n") { e ->
                e.time.toString() + "\t" + e.text.replace('\n', ' ').replace('\t', ' ')
            })
        } catch (e: Exception) {
            Log.w("WifiAutopilot", "Couldn't save the log", e)
        }
    }

    private fun read(): List<Entry> {
        return try {
            if (!file.exists()) return emptyList()
            file.readLines().mapNotNull { line ->
                val tab = line.indexOf('\t')
                if (tab <= 0) return@mapNotNull null
                val time = line.substring(0, tab).toLongOrNull() ?: return@mapNotNull null
                Entry(time, line.substring(tab + 1))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
