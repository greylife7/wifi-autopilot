package com.ershad.wifiautopilot.control

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuRemoteProcess
import java.lang.reflect.Method
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Runs shell commands through Shizuku, i.e. as Android's "shell" user (the same rights as
 * `adb shell`): no root, no pop-ups, works with the screen off and locked.
 *
 * Used ONCE, during the one-time setup, to grant the app a permanent permission
 * (WRITE_SECURE_SETTINGS). After that Shizuku can be uninstalled: everything the automation does at
 * runtime uses that permanent permission, not Shizuku. While Shizuku happens to be installed it is
 * also offered as a convenience for importing saved networks and as a data-switch fallback.
 */
object ShizukuHelper {
    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    const val SHIZUKU_RELEASES_URL = "https://github.com/RikkaApps/Shizuku/releases/latest"
    private const val PERMISSION_REQUEST_CODE = 4242

    enum class State { NOT_INSTALLED, NOT_RUNNING, NO_PERMISSION, READY }

    data class Result(val code: Int, val out: String, val err: String) {
        val ok: Boolean get() = code == 0
    }

    private lateinit var app: Context
    private val _state = MutableStateFlow(State.NOT_RUNNING)
    val state: StateFlow<State> = _state.asStateFlow()
    private val readyListeners = CopyOnWriteArrayList<(Boolean) -> Unit>()

    fun init(context: Context) {
        app = context.applicationContext
        Shizuku.addBinderReceivedListenerSticky { refresh() }
        Shizuku.addBinderDeadListener { refresh() }
        Shizuku.addRequestPermissionResultListener { _, _ -> refresh() }
        refresh()
    }

    fun addReadyListener(listener: (Boolean) -> Unit) { readyListeners += listener }
    fun removeReadyListener(listener: (Boolean) -> Unit) { readyListeners -= listener }

    /** Re-reads Shizuku's state and tells listeners if "ready" changed. */
    @Synchronized
    fun refresh() {
        val wasReady = _state.value == State.READY
        val now = computeState()
        _state.value = now
        val isReady = now == State.READY
        if (isReady != wasReady) readyListeners.forEach { it(isReady) }
    }

    fun isReady(): Boolean = computeState() == State.READY

    fun isInstalled(): Boolean = try {
        app.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /** Installed Shizuku version (e.g. "13.6.0"), or null when it isn't installed. */
    fun installedVersion(): String? = try {
        app.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0).versionName
    } catch (e: Throwable) {
        null
    }

    /**
     * Shows Shizuku's "Allow Wi-Fi Autopilot?" dialog.
     * Returns false if Shizuku won't show it (user chose "Deny and don't ask again") –
     * then access must be switched on inside the Shizuku app.
     */
    fun requestPermission(): Boolean = try {
        if (Shizuku.shouldShowRequestPermissionRationale()) {
            false
        } else {
            Shizuku.requestPermission(PERMISSION_REQUEST_CODE)
            true
        }
    } catch (e: Throwable) {
        false
    }

    private fun computeState(): State {
        val running = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        if (!running) return if (::app.isInitialized && isInstalled()) State.NOT_RUNNING else State.NOT_INSTALLED
        val granted = try {
            !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
        return if (granted) State.READY else State.NO_PERMISSION
    }

    // Shizuku keeps newProcess() private in API 13 but still supports it; reflection is the
    // standard way to use it for simple one-shot commands like ours.
    private val newProcessMethod: Method? by lazy {
        try {
            Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java,
            ).apply { isAccessible = true }
        } catch (e: Throwable) {
            null
        }
    }

    /** Runs [command] with `sh -c` as the shell user. Blocking: never call on the main thread. */
    fun run(command: String, timeoutMs: Long = 15_000L): Result {
        if (!isReady()) return Result(-1, "", "Shizuku is not running")
        val method = newProcessMethod ?: return Result(-1, "", "This Shizuku version isn't supported")
        val process = try {
            method.invoke(null, arrayOf("sh", "-c", command), null, null) as ShizukuRemoteProcess
        } catch (e: Throwable) {
            return Result(-1, "", (e.cause ?: e).toString())
        }
        try { process.outputStream.close() } catch (e: Throwable) { /* no stdin needed */ }

        val out = StringBuffer()
        val err = StringBuffer()
        val outReader = thread(name = "shizuku-out") {
            try { process.inputStream.bufferedReader().forEachLine { out.append(it).append('\n') } } catch (e: Throwable) { }
        }
        val errReader = thread(name = "shizuku-err") {
            try { process.errorStream.bufferedReader().forEachLine { err.append(it).append('\n') } } catch (e: Throwable) { }
        }
        val finished = try { process.waitForTimeout(timeoutMs, TimeUnit.MILLISECONDS) } catch (e: Throwable) { false }
        if (!finished) {
            try { process.destroy() } catch (e: Throwable) { }
        }
        outReader.join(2_000)
        errReader.join(2_000)
        val code = if (finished) {
            try { process.exitValue() } catch (e: Throwable) { -1 }
        } else {
            -2
        }
        val errText = err.toString().trim().ifEmpty { if (finished) "" else "Timed out" }
        return Result(code, out.toString().trim(), errText)
    }
}
