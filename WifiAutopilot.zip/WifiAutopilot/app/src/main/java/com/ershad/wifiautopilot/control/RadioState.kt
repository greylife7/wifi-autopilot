package com.ershad.wifiautopilot.control

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.SystemClock
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import com.ershad.wifiautopilot.core.systemService

/** Reading the radios and Wi-Fi scans. Scanning works while Wi-Fi is OFF when "Wi-Fi scanning" is on. */
object RadioState {

    /** A nearby network seen in a Wi-Fi scan. */
    data class Seen(val ssid: String, val rssi: Int)

    /** One scan's results. [key] changes whenever a new scan has happened. */
    data class ScanSnapshot(val results: List<Seen>, val key: Long)

    private const val MAX_RESULT_AGE_MS = 5 * 60_000L

    private fun wifi(ctx: Context): WifiManager = ctx.applicationContext.systemService()

    fun isWifiOn(ctx: Context): Boolean = wifi(ctx).isWifiEnabled

    /** State of the mobile-data switch: true/false, or null when it can't be read (e.g. no SIM). */
    fun isMobileDataOn(ctx: Context): Boolean? {
        val tm = ctx.getSystemService(TelephonyManager::class.java) ?: return null
        return try {
            tm.isDataEnabled
        } catch (e: Throwable) {
            val v = try {
                Settings.Global.getInt(ctx.contentResolver, mobileDataKey(ctx), -1)
            } catch (e2: Throwable) {
                -1
            }
            if (v < 0) null else v == 1
        }
    }

    /** (connected to any Wi-Fi, that Wi-Fi has validated internet) */
    fun wifiLink(ctx: Context): Pair<Boolean, Boolean> {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false to false
        var connected = false
        var internet = false
        @Suppress("DEPRECATION")
        val networks = try { cm.allNetworks } catch (e: Throwable) { emptyArray() }
        for (n in networks) {
            val caps = try { cm.getNetworkCapabilities(n) } catch (e: Throwable) { null } ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                connected = true
                if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) internet = true
            }
        }
        return connected to internet
    }

    /** Is a cellular data connection actually up right now (not just the switch)? */
    fun isCellularDataActive(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
        @Suppress("DEPRECATION")
        val networks = try { cm.allNetworks } catch (e: Throwable) { emptyArray() }
        return networks.any { n ->
            val caps = try { cm.getNetworkCapabilities(n) } catch (e: Throwable) { null }
            caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }
    }

    /** Name of the connected Wi-Fi, or null (needs location permission to be readable). */
    fun connectedSsid(ctx: Context): String? {
        @Suppress("DEPRECATION")
        val info = try { wifi(ctx).connectionInfo } catch (e: Throwable) { null } ?: return null
        return cleanSsid(info.ssid)
    }

    /** Removes Android's quotes; returns null for hidden/unknown names. */
    fun cleanSsid(raw: String?): String? {
        if (raw == null) return null
        val s = raw.removeSurrounding("\"")
        if (s.isBlank() || s == "<unknown ssid>" || s == "0x") return null
        return s
    }

    /**
     * The per-SIM key telephony actually uses: "mobile_data" on single-SIM phones,
     * "mobile_data" + subscription ID (not slot number) on dual-SIM phones.
     */
    fun mobileDataKey(ctx: Context): String {
        val tm = ctx.getSystemService(TelephonyManager::class.java)
        @Suppress("DEPRECATION")
        val slots = try { tm?.phoneCount ?: 1 } catch (e: Throwable) { 1 }
        val subId = SubscriptionManager.getDefaultDataSubscriptionId()
        return if (slots > 1 && subId >= 0) "mobile_data$subId" else "mobile_data"
    }

    // ---------------------------------------------------------------- scanning

    /** Asks for a fresh Wi-Fi scan. Its results also feed Android's own "Turn on Wi-Fi automatically". */
    fun startScan(ctx: Context): Boolean {
        // The shell user is exempt from Android's scan throttling (4 scans / 2 min).
        if (ShizukuHelper.isReady() && ShizukuHelper.run("cmd wifi start-scan").ok) return true
        @Suppress("DEPRECATION")
        return try { wifi(ctx).startScan() } catch (e: Throwable) { false }
    }

    /** Latest scan results. Uses the normal API, or Shizuku if the app can't read them itself. */
    fun readScan(ctx: Context): ScanSnapshot? {
        val api = try { wifi(ctx).scanResults ?: emptyList() } catch (e: Throwable) { emptyList() }
        if (api.isNotEmpty()) {
            val nowUs = SystemClock.elapsedRealtime() * 1000L
            val fresh = api.filter { nowUs - it.timestamp < MAX_RESULT_AGE_MS * 1000L }
            @Suppress("DEPRECATION")
            val seen = fresh.mapNotNull { r ->
                val name = r.SSID
                if (name.isNullOrBlank()) null else Seen(name, r.level)
            }
            return ScanSnapshot(seen, api.maxOf { it.timestamp })
        }
        if (ShizukuHelper.isReady()) {
            val r = ShizukuHelper.run("cmd wifi list-scan-results")
            if (r.ok) return parseShellScan(r.out)
        }
        return null
    }

    // Matches the start of a `cmd wifi list-scan-results` line up to the SSID column:
    //   "  aa:bb:cc:dd:ee:ff       5180        -61(0:-63/1:-64)     3.214    MyHome    [WPA2-PSK-CCMP][ESS]"
    private val SCAN_LINE = Regex(
        """^\s*((?:[0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2})\s+(\d+)\s+(-?\d+)(?:\([^)]*\))?\s+(\S+) {4}"""
    )

    internal fun parseShellScan(out: String): ScanSnapshot {
        val seen = ArrayList<Seen>()
        var key = 17L
        for (line in out.lineSequence()) {
            val m = SCAN_LINE.find(line) ?: continue
            val bssid = m.groupValues[1]
            val rssi = m.groupValues[3].toIntOrNull() ?: continue
            val age = m.groupValues[4]
            val ageSec = age.toDoubleOrNull()
            if (age.startsWith(">") || (ageSec != null && ageSec * 1000 > MAX_RESULT_AGE_MS)) continue
            val start = m.range.last + 1
            if (start >= line.length) continue
            // SSID is printed in a 32-character column
            val ssid = line.substring(start, minOf(line.length, start + 32)).trimEnd()
            if (ssid.isBlank()) continue
            seen += Seen(ssid, rssi)
            key = key * 31 + (bssid + rssi).hashCode()
        }
        return ScanSnapshot(seen, key)
    }

    /** Saved Wi-Fi networks on the phone (via Shizuku: `cmd wifi list-networks`). */
    fun importSavedNetworks(): Result<List<String>> {
        if (!ShizukuHelper.isReady()) {
            return Result.failure(IllegalStateException("Shizuku isn't running — start it, or type the names in"))
        }
        val r = ShizukuHelper.run("cmd wifi list-networks")
        if (!r.ok) return Result.failure(IllegalStateException(r.err.ifBlank { "Couldn't read saved networks" }))
        // Lines look like: "3            MyHome                           wpa2-psk"
        val row = Regex("""^\s*(\d+)\s+(.+?)\s+(\S+)\s*$""")
        val names = r.out.lineSequence()
            .mapNotNull { row.find(it)?.groupValues?.get(2)?.trim()?.removeSurrounding("\"") }
            .filter { it.isNotBlank() }
            .distinct()
            .toList()
        return Result.success(names)
    }

    /** For the "Scan now" test button: scans and describes what it saw. */
    fun scanReport(ctx: Context, saved: List<String>): String {
        startScan(ctx)
        Thread.sleep(5_000)
        val snap = readScan(ctx)
        if (snap == null || snap.results.isEmpty()) {
            return "Scan: nothing visible. Check that Location and Wi-Fi scanning are ON and location is allowed all the time."
        }
        val mine = saved.mapNotNull { name ->
            val best = snap.results.filter { it.ssid.trim().equals(name.trim(), ignoreCase = true) }.maxOfOrNull { it.rssi }
            if (best == null) null else "$name ($best dBm)"
        }
        val total = snap.results.map { it.ssid }.distinct().size
        return if (mine.isEmpty()) {
            "Scan: $total networks nearby, none of yours."
        } else {
            "Scan: $total networks nearby. Yours: " + mine.joinToString(", ")
        }
    }
}
