package com.ershad.wifiautopilot.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.ershad.wifiautopilot.control.DualEngineController
import com.ershad.wifiautopilot.control.SystemSettings
import com.ershad.wifiautopilot.core.ActivityLog
import com.ershad.wifiautopilot.core.Notifications
import com.ershad.wifiautopilot.core.Prefs
import kotlin.concurrent.thread

/**
 * Event-driven foreground service that keeps the [AutomationEngine] alive. It does no polling of
 * its own – it only reacts to Android events – so it costs almost no battery.
 */
class AutomationForegroundService : Service() {

    companion object {
        const val ACTION_STOP = "com.ershad.wifiautopilot.action.STOP"

        @Volatile
        var engine: AutomationEngine? = null
            private set

        val isRunning: Boolean get() = engine != null

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, AutomationForegroundService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AutomationForegroundService::class.java))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Android requires startForeground() promptly after startForegroundService(), every time.
        if (!goForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_STOP) {
            Prefs.update { it.copy(automationOn = false) }
            val ctx = applicationContext
            thread(name = "autopilot-stop") {
                SystemSettings.restoreAlwaysOn(ctx)
                DualEngineController.restoreMobileData(ctx)
            }
            ActivityLog.add("Automation turned off from the notification")
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Prefs.current.automationOn) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (engine == null) {
            engine = AutomationEngine(applicationContext).also { it.start() }
        }
        return START_STICKY
    }

    private fun goForeground(): Boolean = try {
        val notification = Notifications.statusNotification(this)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(Notifications.ID_STATUS, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(Notifications.ID_STATUS, notification)
        }
        true
    } catch (e: Exception) {
        ActivityLog.add("Android didn't allow the background service to start: ${e.javaClass.simpleName}. Open the app once.")
        false
    }

    override fun onDestroy() {
        engine?.stop()
        engine = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
