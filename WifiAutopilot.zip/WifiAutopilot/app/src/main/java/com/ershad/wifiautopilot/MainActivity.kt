package com.ershad.wifiautopilot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.ershad.wifiautopilot.control.ShizukuHelper
import com.ershad.wifiautopilot.core.Prefs
import com.ershad.wifiautopilot.service.AutomationForegroundService
import com.ershad.wifiautopilot.ui.AutopilotTheme
import com.ershad.wifiautopilot.ui.MainScreen

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AutopilotTheme {
                MainScreen()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        ShizukuHelper.refresh()
        // If Vivo's battery manager stopped the service, opening the app brings it back.
        if (Prefs.current.automationOn && !AutomationForegroundService.isRunning) {
            try {
                AutomationForegroundService.start(this)
            } catch (e: Exception) {
                // ignored: the dashboard shows "Background service: Stopped"
            }
        }
    }
}
