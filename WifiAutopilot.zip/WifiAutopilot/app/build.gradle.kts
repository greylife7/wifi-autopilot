plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// A fixed signing key means every new build installs right over the old one
// (no uninstall needed, so the permanent permissions, settings and log are kept).
val fixedKey = rootProject.file("keystore/autopilot.keystore")

android {
    namespace = "com.ershad.wifiautopilot"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ershad.wifiautopilot"
        minSdk = 26
        // Deliberately 28 (Android 9). Android 10-16 still let apps that target 28 or lower switch
        // Wi-Fi with WifiManager.setWifiEnabled(): silent, works with the phone locked and after
        // every reboot, with no Shizuku and no accessibility service (banking apps such as bKash
        // block sideloaded apps that use one). Android 16 installs apps that target 24 or newer
        // and only shows its "built for an older version" warning below 28.
        // Personal use only (Google Play would require a newer target).
        targetSdk = 28
        versionCode = 7
        versionName = "5.0"
    }

    signingConfigs {
        if (fixedKey.exists()) {
            create("fixed") {
                storeFile = fixedKey
                storePassword = "autopilot"
                keyAlias = "autopilot"
                keyPassword = "autopilot"
            }
        }
    }

    buildTypes {
        getByName("debug") {
            if (fixedKey.exists()) signingConfig = signingConfigs.getByName("fixed")
        }
        getByName("release") {
            isMinifyEnabled = false
            if (fixedKey.exists()) signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    lint {
        // The old targetSdk is intentional (see above); lint must never block a build because of it.
        disable += setOf("ExpiredTargetSdkVersion", "OldTargetApi")
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")

    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    // Shizuku: used ONCE, during the one-time setup, to grant the app a permanent permission
    // (WRITE_SECURE_SETTINGS). It is not needed afterwards and can be uninstalled.
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
